package crawler.stormlite.distributed;

import java.io.IOException;

import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.KeyDeserializer;

public class StringIntPairKeyDeserializer extends KeyDeserializer {

    @Override
    public Object deserializeKey(String arg0, DeserializationContext arg1) throws IOException {
        return null;
    }
}
