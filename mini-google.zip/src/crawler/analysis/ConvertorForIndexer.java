package crawler.analysis;

/**
 * 
 * @author xiaofandou
 *
 */
public class ConvertorForIndexer {

	public static void main(String[] args) {
		
	}
	
}
