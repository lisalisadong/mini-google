package utils;

public class Constants {

	public static final int TOTAL_DOC_NUM = 396500;
	public static final double TF_FACTOR = 0.5;

}
