package searchengine.weather;

/**
 * Created by QingxiaoDong on 5/5/17.
 */
public class WeatherInfo {
    public String city;
    public String value;
    public String min;
    public String max;
    public String humidity;
    public String wind;
    public String time;
    public String icon;
    public String weather;
}
