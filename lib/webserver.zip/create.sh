#!/bin/sh

echo "aa\nbb\nabc\0lll" > file.txt
