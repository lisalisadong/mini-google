#!/bin/sh

a="open localhost $1"

echo "\nTEST 1:\n"
m="GET /index.html HTTP/1.0\n\n"
echo $m
(
echo $a
sleep 1
echo $m
sleep 1
) | telnet

echo "\nTEST 2:\n"
m="GET /index.html HTTP/1.1\n\n"
echo $m
(
echo $a
sleep 1
echo $m
sleep 3
) | telnet

echo "\nTEST 3:\n"
m="GET /index.html HTTP/1.1\nHost: localhost:1234\nConnection: keep-alive\nUpgrade-Insecure-Requests: 1\nUser-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\nAccept-Encoding: gzip, deflate, sdch, br\nAccept-Language: zh-CN,zh;q=0.8,de-DE;q=0.6,de;q=0.4,en-US;q=0.2,en;q=0.2,zh-TW;q=0.2\nIf-Modified-Since: Wed, 22 Jul 2009 19:15:56 GMT\n\n"
echo $m
(
echo $a
sleep 1
echo $m
sleep 1
) | telnet

echo "\nTEST 4:\n"
m="GET http://localhost/index.html HTTP/1.0\n\n"
echo $m
(
echo $a
sleep 1
echo $m
sleep 1
) | telnet

echo "\nTEST 5:\n"
m="GET http://localhost/index.html HTTP/1.1\nHost: localhost:1234\n"
echo $m
(
echo $a
sleep 1
echo $m
sleep 1
) | telnet
