package edu.upenn.cis455.webserver;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by QingxiaoDong on 2/11/17.
 */

public class HttpUtils {

    public static HashMap<String, HttpServletApplication> applicationMapping = new HashMap<String, HttpServletApplication>();

    public static HttpServletApplication dispatchApplication(String url) {
        if (url == null || url.length() <= 1) return applicationMapping.get("/");
        int i = url.indexOf("/", 1);
        String cp = "/";
        if (i > 0) cp = url.substring(0, i);
        if (applicationMapping.containsKey(cp)) {
            return applicationMapping.get(cp);
        } else {
            return applicationMapping.get("/");
        }
    }

    public static String convertTimeLongToString(long time) {
        Date d = new Date(time);
        SimpleDateFormat ft = new SimpleDateFormat ("EEE, dd MMM yyyy HH:mm:ss z");
        ft.setTimeZone(TimeZone.getTimeZone("GMT"));
        return ft.format(d);
    }

    public static long convertTimeStringToLong(String timeString) {

        // first format
        DateFormat formatter = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        try {
            Date date = formatter.parse(timeString);
            return date.getTime();
        } catch (ParseException e) {

        }
        // second format
        formatter = new SimpleDateFormat("EEE, dd-MMM-yy HH:mm:ss z");
        try {
            Date date = formatter.parse(timeString);
            return date.getTime();
        } catch (ParseException e) {

        }
        // third format
        formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy");
        try {
            Date date = formatter.parse(timeString);
            return date.getTime();
        } catch (ParseException e) {

        }
        return -1;
    }

    public static boolean validateTimeFormat(String timeString, HttpEnum version) {

        DateFormat formatter = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        try {
            Date date = formatter.parse(timeString);
            return true;
        } catch (ParseException e) {
            if (version == HttpEnum.VERSION_11) return false;
            // try others
        }
        formatter = new SimpleDateFormat("EEE, dd-MMM-yy HH:mm:ss z");
        try {
            Date date = formatter.parse(timeString);
            return true;
        } catch (ParseException e) {
            // try the other
        }
        formatter = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy");
        try {
            Date date = formatter.parse(timeString);
            return true;
        } catch (ParseException e) {
            // last chance wasted
        }
        return false;
    }

    public static String getSEASLogin() {
        return "<h3 style=\"color:blue;\">Qingxiao Dong (qingxiao)</h3>\n";
    }

    public static String getShutdownButton() {
        return "<a href=/shutdown><button style=\"color:red;\">shutdown http server</button></a>\n";
    }

    public static String getFullLogButton() {
        return "<a href=/full_log><button style=\"color:black;\">View Full Logs</button></a>\n";
    }

    public static String getErrorLogButton() {
        return "<a href=/error_log><button style=\"color:black;\">View Error Logs</button></a>\n";
    }

    public static String getManageApplicationsButton() {
        return "<a href=/manage_applications><button style=\"color:blue;\">Manage Applications</button></a>\n";
    }

    // not required
    public static String getReturnButton() {
        return "<a href=/><button style=\"color:green;\">return to home</button></a>\n";
    }

    // not required
    public static String getControlButton() {
        return "<a href=/control><button style=\"color:green;\">go to control panel</button></a>\n";
    }
}
