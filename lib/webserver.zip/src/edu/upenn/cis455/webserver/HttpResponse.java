package edu.upenn.cis455.webserver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Generates HTTP response
 */
public class HttpResponse {

    private Logger logger = new Logger(this.getClass().getSimpleName());
    private InputStream fileStream;
    private OutputStream out;
    private HttpRequest request;
    private HttpEnum version;
    private HttpEnum status;
    private String messageBody;
    private String rootDir;
    private String hostName;
    private HashMap<HttpEnum, String> headers;
    private static final String SERVER_NAME = "Qingxiao's Server/1.0";
    private static final String CRLF = "\r\n";

    public boolean shutdownRequested;

    public HttpResponse(HttpRequest req, OutputStream stream, String dir, String port) {
        request = req;
        out = stream;
        shutdownRequested = false;
        headers = new HashMap<HttpEnum, String>();
        rootDir = dir;
        hostName =  "http://localhost:" + port + "/";
        if (rootDir.charAt(rootDir.length() - 1) != '/') rootDir += "/";
    }

    /**
     * Send 100 continue to HTTP/1.1 clients
     */
    public void processContinueResponse() {
        if (!request.timeout && !request.badRequest && request.continueExpected
                && request.version == HttpEnum.VERSION_11) {
            version = HttpEnum.VERSION_11;
            status = HttpEnum.STATUS_100_CONTINUE;
            writeResponse(getInitialResponse() + CRLF);
        }
    }

    /**
     * Send full response to clients
     */
    public void processFullResponse(){
        if (request.emptyRequest) return;

        version = (request.version == null) ? HttpEnum.VERSION_11 : request.version;

        if (request.timeout) {
            status = HttpEnum.STATUS_408_REQUEST_TIMEOUT;
            setMessageHtml(status.text());
        }
        else if (request.badRequest) {
            status = HttpEnum.STATUS_400_BAD_REQUEST;
            setMessageHtml(status.text() + "<br>" + request.errorText);
        }

        else if (request.notImplemented) {
            status = HttpEnum.STATUS_501_NOT_IMPLEMENTED;
            setMessageHtml(status.text());
        }

        else if (request.notSupported) {
            status = HttpEnum.STATUS_505_HTTP_VERSION_NOT_SUPPORTED;
            setMessageHtml(status.text());
        }

        else if (request.otherExpected) {
            status = HttpEnum.STATUS_417_EXPECTATION_FAILED;
            setMessageHtml(status.text());
        }

        else if (request.serverError) {
            status = HttpEnum.STATUS_500_SERVER_ERROR;
            setMessageHtml(status.text());
        }

        else {
            String url = request.pathToFile;
            logger.trace("Looking for {}", url);

            // handle /shutdown
            if (url.equals("/shutdown")) {
                shutdownRequested = true;
                status = HttpEnum.STATUS_200_OK;
                setMessageHtml("Server shutdown requested!");
            }

            // handle /control
            else if (url.equals("/control")) {
                status = HttpEnum.STATUS_200_OK;
                setMessageHtml(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                        HttpUtils.getShutdownButton() + HttpUtils.getManageApplicationsButton() +
                        HttpUtils.getFullLogButton() + HttpUtils.getErrorLogButton() + getThreadStates());
            }

            // handle /full_log
            else if (url.equals("/full_log")) {
                status = HttpEnum.STATUS_200_OK;
                try {
                    File file = new File("full_log.txt");
                    fileStream = new FileInputStream(file);
                    headers.put(HttpEnum.HEADER_CONTENT_TYPE, getContentType(file.getName()).text());
                    headers.put(HttpEnum.HEADER_CONTENT_LENGTH, String.valueOf(file.length()));
                } catch (FileNotFoundException e) {
                    logger.error(e, "Error opening full log");
                }
            }

            // handle /error_log
            else if (url.equals("/error_log")) {
                status = HttpEnum.STATUS_200_OK;
                try {
                    File file = new File("error_log.txt");
                    fileStream = new FileInputStream(file);
                    headers.put(HttpEnum.HEADER_CONTENT_TYPE, getContentType(file.getName()).text());
                    headers.put(HttpEnum.HEADER_CONTENT_LENGTH, String.valueOf(file.length()));
                } catch (FileNotFoundException e) {
                    logger.error(e, "Error opening error log");
                }
            }

            else if (request.method == HttpEnum.METHOD_POST) {
                // do nothing
                status = HttpEnum.STATUS_200_OK;
            }

            else {
                url = simplifyPath(url);
                File file = new File(rootDir + url);
                if (!securePath(url)) {
                   // 403
                    status = HttpEnum.STATUS_403_FORBIDDEN;
                    setMessageHtml(status.text() + "<br>You can not go beyond the root directory");
                }
                else if (!file.exists()) {
                    // 404
                    status = HttpEnum.STATUS_404_NOT_FOUND;
                    setMessageHtml(status.text());
                } else if (!file.canRead()) {
                    // 403
                    status = HttpEnum.STATUS_403_FORBIDDEN;
                    setMessageHtml(status.text() + "<br>Permission denied");
                } else if (validModifiedTime(file.lastModified()) != HttpEnum.STATUS_200_OK) {
                    // last modified time
                    status = validModifiedTime(file.lastModified());
                } else {
                    // 200 OK
                    status = HttpEnum.STATUS_200_OK;
                    headers.put(HttpEnum.HEADER_LAST_MODIFIED, HttpUtils.convertTimeLongToString(file.lastModified()));
                    headers.put(HttpEnum.HEADER_CONTENT_TYPE, getContentType(file.getName()).text());

                    if (file.isDirectory()) {
                        File[] files = file.listFiles();
                        setMessageHtml(getDirectoryString(files, url));
                    } else if (file.isFile()) {
                        headers.put(HttpEnum.HEADER_CONTENT_LENGTH, String.valueOf(file.length()));
                        try {
                            fileStream = new FileInputStream(file);
                        } catch (FileNotFoundException e) {
                            // SecurityException if a security manager exists and its
                            status = HttpEnum.STATUS_500_SERVER_ERROR;
                            setMessageHtml(status.text());
                        }
                    }
                }
            }
        }

        // add necessary headers
        headers.put(HttpEnum.HEADER_CONNECTION, "close"); // RFC 11.10
        headers.put(HttpEnum.HEADER_DATE, getTimestamp()); // all response must include date
        headers.put(HttpEnum.HEADER_SERVER, SERVER_NAME);

        // without message body
        if (status == HttpEnum.STATUS_412_PRECONDITION_FAILED) {
            writeInitialLine();
            writeHeaders();
            return;
        }

        // without message body
        if (status == HttpEnum.STATUS_304_NOT_MODIFIED) {
            writeInitialLine();
            writeHeaders();
            return;
        }

        // all other cases
        writeInitialLine();
        writeHeaders();

        // message body
        if (request.method != HttpEnum.METHOD_HEAD) {
        	writeMessageBody();
        }
    }

    /**
     * Removes ".." and "." and duplicate "/" in paths
     */
    private String simplifyPath(String path) {
        if (path.length() == 0) return path;
        String result = "";
        String[] stubs = path.split("/+");
        ArrayList<String> paths = new ArrayList<String>();
        for (String s : stubs){
            if(s.equals("..")){
                if(paths.size() > 0){
                    if (!paths.get(paths.size() - 1).equals("..")) paths.remove(paths.size() - 1);
                } else {
                    paths.add(s);
                }
            }
            else if (!s.equals(".") && !s.equals("")){
                paths.add(s);
            }
        }
        for (String s : paths){
            result += "/" + s;
        }
        return result.length() == 0 ? result : result.substring(1);
    }

    /**
     * Helper functions to write response to output stream
     */

    private void writeResponse(String response) {
        try {
            out.write(response.getBytes());
        } catch (IOException e) {
            logger.error(e, "IOException when writing output stream");
        }
    }

    private String getInitialResponse() {
        return version.text() + " " + status.text() + CRLF;
    }

    private void writeInitialLine() {
        writeResponse(getInitialResponse());
    }


    private String getHeaderLine(HttpEnum header, String value) {
        return header.text() + ": " + value + CRLF;
    }

    private void writeHeaders() {
        for (HashMap.Entry<HttpEnum, String> entry : headers.entrySet()) {
            writeResponse(getHeaderLine(entry.getKey(), entry.getValue()));
        }
        writeResponse(CRLF);
    }

    private void setMessageBody(String type, String body) {
        headers.put(HttpEnum.HEADER_CONTENT_TYPE, type);
        headers.put(HttpEnum.HEADER_CONTENT_LENGTH, Integer.toString(body.length()));
        messageBody = body;
    }


    private void writeMessageBody() {

        // message body
        if (fileStream != null) {
            byte[] buffer = new byte[30720];
            try {
                int bytesRead = fileStream.read(buffer);
                while (bytesRead != -1) {
                    out.write(buffer, 0, bytesRead);
                    out.flush();
                    bytesRead = fileStream.read(buffer);
                }
                fileStream.close();
            } catch (IOException e) {
                logger.error(e, "IOExcepting when reading from file stream and writing to output stream");
            }
            // writeResponse(CRLF);
        } else if (messageBody != null) {
            writeResponse(messageBody);
        } else {
            writeResponse(CRLF);
        }
    }

    /**
     * Helper functions to help generating the html
     */

    private void setMessageHtml(String message) {

        setMessageBody(HttpEnum.CONTENT_TEXT_HTML.text(),
                "<html>\n  <body>\n    " + message + "\n  </body>\n</html>" + CRLF);
    }

    private String getDirectoryString(File[] files, String prefix) {
        String res = "<h3 style=\"color:blue;\">" + hostName + prefix + "</h3>\n";
        res += "<p>" + HttpUtils.getControlButton() + "</p>";
        for (File f : files) {
            res += getFileString(f.getName(), prefix);
        }
        return res;
    }

    private String getFileString(String filename, String prefix) {
        if (prefix.length() == 0) prefix = "/";
        else if (!prefix.equals("/")) prefix = "/" + prefix + "/";
        return "<p><a href=" + prefix + filename + ">" + filename + "</a></p>\n";
    }


    /**
     * Get threads' state in thread pool. Runnable will display the filepath.
     */
    private String getThreadStates() {
        String res = "";
        for (Thread t : HttpServer.pool) {
            if (t.getState() == Thread.State.WAITING) {
                res += "<p>" + t.getName() + ": waiting</p>";
            } else {
                res += "<p>" + t.getName() + ": " + HttpServer.workMapping.get(t) + "</p>";
            }
        }
        return res;
    }

    /**
     * Helper functions regarding the timestamp
     */

    private String getTimestamp() {
        Date now = new Date( );
        SimpleDateFormat ft = new SimpleDateFormat ("EEE, dd MMM yyyy HH:mm:ss z");
        ft.setTimeZone(TimeZone.getTimeZone("GMT"));
        return ft.format(now);
    }

    private HttpEnum validModifiedTime(long lastModified) {
        if (request.headers.containsKey(HttpEnum.HEADER_IF_MODIFIED_SINCE)) {
            long time = HttpUtils.convertTimeStringToLong(request.headers.get(HttpEnum.HEADER_IF_MODIFIED_SINCE));
            if (time != -1 && time > lastModified) {
                return HttpEnum.STATUS_304_NOT_MODIFIED;
            }
        }
        if (request.headers.containsKey(HttpEnum.HEADER_IF_UNMODIFIED_SINCE)) {
            long time = HttpUtils.convertTimeStringToLong(request.headers.get(HttpEnum.HEADER_IF_UNMODIFIED_SINCE));
            if (time != -1 && time < lastModified) {
                return HttpEnum.STATUS_412_PRECONDITION_FAILED;
            }
        }
        return HttpEnum.STATUS_200_OK;
    }

    /**
     * Check if a path goes beyond root directory. Return true if it's safe.
     */
    private boolean securePath(String path) {
        return !path.startsWith("..");
    }

    /**
     * Get content type of a file. The unrecognized type will be set to application/octet-stream
     */
    private HttpEnum getContentType(String filename) {
        int dot = filename.lastIndexOf(".");
        if (dot == -1) {
            return HttpEnum.CONTENT_APPLICATION_OCTET_STREAM;
        }
        String ext = filename.substring(dot + 1).toLowerCase();
        if (ext.equals("html")) {
            return HttpEnum.CONTENT_TEXT_HTML;
        } else if (ext.equals("txt")) {
            return HttpEnum.CONTENT_TEXT_PLAIN;
        } else if (ext.equals("jpg")) {
            return HttpEnum.CONTENT_IMAGE_JPEG;
        } else if (ext.equals("gif")) {
            return HttpEnum.CONTENT_IMAGE_GIF;
        } else if (ext.equals("png")) {
            return HttpEnum.CONTENT_IMAGE_PNG;
        } else if (ext.equals("pdf")) {
            return HttpEnum.CONTENT_APPLICATION_PDF;
        } else if (ext.equals("xml")) {
            return HttpEnum.CONTENT_APPLICATION_XML;
        } else {
            return HttpEnum.CONTENT_APPLICATION_OCTET_STREAM;
        }
    }

}
