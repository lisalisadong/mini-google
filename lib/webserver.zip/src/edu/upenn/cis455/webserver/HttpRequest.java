package edu.upenn.cis455.webserver;

import java.io.*;
import java.net.SocketTimeoutException;
import java.util.*;

/**
 * Processes HTTP request
 * http://docs.oracle.com/javaee/6/api/javax/servlet/http/HttpServletRequest.html
 */
public class HttpRequest{

	private InputStream in;
	private Logger logger = new Logger(this.getClass().getSimpleName());
	// private String host; // needed for MS2 potentially
	/* private String[] serverNames = {
			"http://localhost","https://localhost",
			"http://127.0.0.1","https://127.0.0.1",
			"http://www.localhost","www.localhost",
			"http://www.localhost:","www.localhost:",
			"http://localhost:","https://localhost:",
			"http://127.0.0.1:","https://127.0.0.1:","127.0.0.1:",
			"localhost:","127.0.0.1","localhost"}; */

	public HttpEnum method;
	public String rawMethod;
	public String pathToFile;
	public HttpEnum version;
	public String rawVersion;
	public String errorText;
	public String body;
	public HashMap<HttpEnum, String> headers;
	public HashMap<String, Object> rawHeaders;
	public boolean badRequest; //400
	public boolean serverError; //500
	public boolean notSupported; //505
	public boolean notImplemented; //501
	public boolean continueExpected; // 100
	public boolean otherExpected; // 417
	public boolean timeout; // 408
	public boolean emptyRequest;
	public String port;

	public HttpRequest(InputStream stream, String port) {
		in = stream;
		serverError = false;
		badRequest = false;
		notSupported = false;
		notImplemented = false;
		emptyRequest = false;
		continueExpected = false;
		otherExpected = false;
		timeout = false;
		headers = new HashMap<HttpEnum, String>();
		rawHeaders = new HashMap<String, Object>();
		this.port = port;
		// set server names
		// needed for MS2 potentially
		// for (int i = 6; i <= 13; i++) {
		// 	serverNames[i] += port;
		// }
	}

	/**
	 * Read and parse input stream until end of the first line
	 */
	public void processInitialRequest() {
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			int n = in.read();
			while (n != -1) {
				out.write(n);
				if (n == 0xA) {
					// first line ended
					String line = out.toString();
					parseInitialRequest(line);
					return;
				}
				n = in.read();
			}
		} catch (SocketTimeoutException e) {
			logger.trace("Socket timeout. Closing idle connection.");
			timeout = true;
			return;
		} catch (IOException e) {
			serverError = true;
			logger.error(e, "IOException occurs when processing initial request");
			return;
		}
		emptyRequest = true;
	}

	/**
	 * Read and parse input stream until reached the end of request (empty line)
	 */
	public void processFullRequest() {
		String line = "";
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			int n = in.read();
			while (n != -1) {
				out.write(n);
				if (n == 0xA) {
					line += out.toString();
					out.reset();
					if (line.trim().length() == 0) {
						break;
					}
				}
				int next = in.read();
				if (n == 0xA && next != 0x9 && next != 0x20) {
					// single header ended
					addHeader(line);
					line = "";
				}
				n = next;
			}
		} catch (SocketTimeoutException e) {
			logger.trace("Socket timeout. Closing idle connection.");
			timeout = true;
			return;
		} catch (IOException e) {
			serverError = true;
			logger.error(e, "IOException occurs when processing full request.");
			return;
		}

		verifyRequest();
		if (method == HttpEnum.METHOD_POST) {
			processPostBody();
		}
	}

	public void processPostBody() {
		if (!headers.containsKey(HttpEnum.HEADER_CONTENT_LENGTH) ||
				Integer.parseInt(headers.get(HttpEnum.HEADER_CONTENT_LENGTH)) == 0) {
			body = "";
			return;
		}
		int length = Integer.parseInt(headers.get(HttpEnum.HEADER_CONTENT_LENGTH));
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			int count = 0;
			int n = in.read();
			while (n != -1) {
				count++;
				if (count > length) {
					badRequest = true;
					errorText = "Request body length does not match content length";
					break;
				}
				out.write(n);
				if (count == length) break;
				n = in.read();
			}
			if (count < length) {
				badRequest = true;
				errorText = "Request body length does not match content length";
			}
			body = out.toString();
		} catch (SocketTimeoutException e) {
			logger.trace("Socket timeout. Closing idle connection.");
			timeout = true;
			return;
		} catch (IOException e) {
			serverError = true;
			logger.error(e, "IOException occurs when processing full request.");
			return;
		}
	}

	/**
	 * Parse initial request
	 */
	private void parseInitialRequest(String line) {
		String[] toks = line.trim().split("\\s+");
		// bad request (RFC 4.1)
		if (toks.length != 3) {
			badRequest = true;
			errorText = "Initial request must contain method, path and version";
			return;
		}

		// method
		method = HttpEnum.getHttpEnumCaseSensitive(toks[0]);
		if (method == null) { // not implemented (RFC 5.1.1)
			notImplemented = true;
			rawMethod = toks[0];
		}

		// path to file
		pathToFile = toks[1];
		if (pathToFile.startsWith("http")) {
			int i = pathToFile.indexOf("/", 8);
			if (i == -1) {
				// no abs-path -> should be root "/" RFC3.2.3
				// host = pathToFile;
				pathToFile = "/";
			} else {
				// host = pathToFile.substring(0, i);
				pathToFile = pathToFile.substring(i);
			}
		}
		if (pathToFile != null && !pathToFile.startsWith("/")) {
			pathToFile = "/" + pathToFile;
		}

		// version
		version = HttpEnum.getHttpEnumCaseSensitive(toks[2]);
		if (version == null) { // http version not supported (RFC 5.6)
			if (HttpEnum.getHttpEnum(toks[2]) != null) {
				badRequest = true;
				errorText = "HTTP version must be uppercase";
				rawVersion = toks[2];
			} else {
				notSupported = true;
			}
		}
	}

	/**
	 *  Parse header line
	 */
	private void addHeader(String line) {
		line = line.trim();
		if (line.length() == 0) return;
		int i = line.indexOf(":");
		if (i == -1) {
			badRequest = true;
			errorText = "Header much be in Header: value format";
		} else {
			String key = line.substring(0, i).trim().toLowerCase();
			String value = line.substring(i + 1).trim();
			if (rawHeaders.containsKey(key)) {
				if (rawHeaders.get(key) instanceof List) {
					((List) rawHeaders.get(key)).add(value);
				} else {
					List<String> values = new ArrayList<String>();
					values.add((String) rawHeaders.get(key));
					values.add(value);
					rawHeaders.put(key, values);
				}
			} else {
				rawHeaders.put(key, value);
			}

			HttpEnum header = HttpEnum.getHttpEnum(key);
			if (header != null) {
				headers.put(header, value);
			} else {
				// ignore unrecognized header
			}
		}
	}

	/**
	 * Verify headers / contents of the request
	 */
	private void verifyRequest() {
		// check 100 continue
		if (version == HttpEnum.VERSION_11 && headers.containsKey(HttpEnum.HEADER_EXPECT)) {
			if (headers.get(HttpEnum.HEADER_EXPECT).equalsIgnoreCase("100-continue")) {
				continueExpected = true;
			} else {
				otherExpected = true;
			}
		}

		// check 1.1 specific
		if (!badRequest && version == HttpEnum.VERSION_11) {
			// contains host
			if (!headers.containsKey(HttpEnum.HEADER_HOST)) {
				badRequest = true;
				errorText = "HTTP 1.1 requests must include the Host: header";
			}
		}

		// check if-modified/unmodified time format
		if (!badRequest && !notSupported && !notImplemented) {
			if (headers.containsKey(HttpEnum.HEADER_IF_MODIFIED_SINCE)) {
				if (!HttpUtils.validateTimeFormat(headers.get(HttpEnum.HEADER_IF_MODIFIED_SINCE), version)) {
					badRequest = true;
					errorText = "If-Modified-Since time mal-formatted";
				}
			}
			if (headers.containsKey(HttpEnum.HEADER_IF_UNMODIFIED_SINCE)) {
				if (!HttpUtils.validateTimeFormat(headers.get(HttpEnum.HEADER_IF_UNMODIFIED_SINCE), version)) {
					badRequest = true;
					errorText = "If-Unmodified-Since time mal-formatted";
				}
			}
		}

		// check host is correct
		// Here says we do not need to check host in MS1 https://piazza.com/class/ixm0lev2juc6f0?cid=129
		// code is left here in case we need it for MS2
		/*
		if (!badRequest) {
			boolean badHost = true;
			for (String name : serverNames) {
				if (host != null) {
					// RFC5.2
					if (host.equalsIgnoreCase(name)) { //RFC3.2.3
						badHost = false;
						break;
					}
				} else if (!headers.containsKey(HttpEnum.HEADER_HOST)){
					badHost = false;
					break;

				} else if (headers.get(HttpEnum.HEADER_HOST).equalsIgnoreCase(name)) {
					badHost = false;
					break;
				}
			}
			if (badHost) {
				badRequest = true;
				errorText = "Host does not match";
			}
		}*/
	}
}
