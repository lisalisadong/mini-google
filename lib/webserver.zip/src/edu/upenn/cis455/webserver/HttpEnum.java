package edu.upenn.cis455.webserver;

/**
 * Stores some recognized enums
 */
public enum HttpEnum {
    // methods
    METHOD_GET ("GET"),
    METHOD_HEAD ("HEAD"),
    METHOD_POST ("POST"),

    // headers
    HEADER_HOST ("Host"),
    HEADER_DATE ("Date"),
    HEADER_SERVER ("Server"),
    HEADER_LAST_MODIFIED ("Last-Modified"),
    HEADER_IF_MODIFIED_SINCE ("If-Modified-Since"),
    HEADER_IF_UNMODIFIED_SINCE ("If-Unmodified-Since"),
    HEADER_CONTENT_TYPE ("Content-Type"),
    HEADER_CONTENT_LENGTH ("Content-Length"),
    HEADER_CONNECTION ("Connection"),
    HEADER_EXPECT ("Expect"),
    HEADER_COOKIE ("Cookie"),
    HEADER_REMOTE_ADDR ("Remote_Addr"),
    HEADER_REMOTE_HOST ("Remote_Host"),
    HEADER_SET_COOKIE ("Set-Cookie"),
    HEADER_LOCATION ("Location"),

    // values
    VERSION_10 ("HTTP/1.0"),
    VERSION_11 ("HTTP/1.1"),

    // status codes
    STATUS_100_CONTINUE ("100 Continue"),
    STATUS_101_SWITCHING_PROTOCOLS ("101 Switching Protocols"),
    STATUS_200_OK ("200 OK"),
    STATUS_201_CREATED ("201 Created"),
    STATUS_202_ACCEPTED ("202 Accepted"),
    STATUS_203_NON_AUTHORITATIVE_INFORMATION ("203 Non-Authoritative Information"),
    STATUS_204_NO_CONTENT ("204 No Content"),
    STATUS_205_RESET_CONTENT ("205 Reset Content"),
    STATUS_206_PARTIAL_CONTENT ("206 Partial Content"),
    STATUS_300_MULTIPLE_CHOICES ("300 Multiple Choices"),
    STATUS_301_MOVED_PERMANENTLY ("301 Moved Permanently"),
    STATUS_302_REDIRECT ("302 Found"),
    STATUS_303_SEE_OTHER ("303 See Other"),
    STATUS_304_NOT_MODIFIED ("304 Not Modified"),
    STATUS_305_USE_PROXY ("305 Use Proxy"),
    STATUS_306_UNUSED ("306 (Unused)"),
    STATUS_307_TEMPORARY_REDIRECT ("307 Temporary Redirect"),
    STATUS_400_BAD_REQUEST ("400 Bad Request"),
    STATUS_401_UNAUTHORIZED ("401 Unauthorized"),
    STATUS_402_PAYMENT_REQUIRED ("402 Payment Required"),
    STATUS_403_FORBIDDEN ("403 Forbidden"),
    STATUS_404_NOT_FOUND ("404 Not Found"),
    STATUS_405_METHOD_NOT_ALLOWED ("405 Method Not Allowed"),
    STATUS_406_NOT_ACCEPTABLE ("406 Not Acceptable"),
    STATUS_407_PROXY_AUTHENTICATION_REQUIRED ("407 Proxy Authentication Required"),
    STATUS_408_REQUEST_TIMEOUT ("408 Request Timeout"),
    STATUS_409_CONFLICT ("409 Conflict"),
    STATUS_410_GONE ("410 Gone"),
    STATUS_411_LENGTH_REQUIRED ("411 Length Required"),
    STATUS_412_PRECONDITION_FAILED ("412 Precondition Failed"),
    STATUS_413_REQUEST_ENTRY_TOO_LARGE ("413 Request Entity Too Large"),
    STATUS_414_REQUEST_URI_TOO_LONG ("414 Request-URI Too Long"),
    STATUS_415_UNSUPPORTED_MEDIA_TYPE ("415 Unsupported Media Type"),
    STATUS_416_REQUESTED_RANGE_NOT_SATISFIABLE ("416 Requested Range Not Satisfiable"),
    STATUS_417_EXPECTATION_FAILED ("417 Expectation Failed"),
    STATUS_500_SERVER_ERROR ("500 Server Error"),
    STATUS_501_NOT_IMPLEMENTED ("501 Not Implemented"),
    STATUS_502_BAD_GATEWAY ("502 Bad Gateway"),
    STATUS_503_SERVICE_UNAVAILABLE ("503 Service Unavailable"),
    STATUS_504_GATEWAY_TIMEOUT ("504 Gateway Timeout"),
    STATUS_505_HTTP_VERSION_NOT_SUPPORTED ("505 HTTP Version Not Supported"),

    // content type
    CONTENT_TEXT_HTML ("text/html"),
    CONTENT_TEXT_PLAIN ("text/plain"),
    CONTENT_IMAGE_GIF ("image/gif"),
    CONTENT_IMAGE_PNG ("image/png"),
    CONTENT_IMAGE_JPEG ("image/jpeg"),
    CONTENT_APPLICATION_PDF ("application/pdf"),
    CONTENT_APPLICATION_XML ("application/xml"),
    CONTENT_APPLICATION_OCTET_STREAM ("application/octet-stream");

    private String text;
    HttpEnum(String s) { text = s; }
    public String text() { return text; }
    public String textLowercase() {return text.toLowerCase();}

    /**
     * Find a HttpEnum by test. Case-insensitive.
     */
    public static HttpEnum getHttpEnum(String s) {
        if (s != null) {
            for (HttpEnum e : HttpEnum.values()) {
                if (s.equalsIgnoreCase(e.text)) {
                    return e;
                }
            }
        }
        return null;
    }

    /**
     * Find a HttpEnum by text. Case-sensitive.
     */
    public static HttpEnum getHttpEnumCaseSensitive(String s) {
        if (s != null) {
            for (HttpEnum e : HttpEnum.values()) {
                if (s.equals(e.text)) {
                    return e;
                }
            }
        }
        return null;
    }

    /**
     * Get a status by status code.
     */
    public static HttpEnum getStatusByCode(int sc) {
        for (HttpEnum e : HttpEnum.values()) {
            if (e.text().substring(0, 3).equals(String.valueOf(sc))) {
                return e;
            }
        }
        return null;
    }
}
