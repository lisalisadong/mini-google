package edu.upenn.cis455.webserver;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLEncoder;
import java.util.Map;

/**
 * Created by QingxiaoDong on 2/19/17.
 */
public class HttpServletApplicationManager extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        if (request.getRequestURI().endsWith("delete")) {
            String contextPath = request.getParameter("context_path");
            String classPath = request.getParameter("classpath");
            String webXmlPath = request.getParameter("webxml_path");
            if (HttpUtils.applicationMapping.containsKey(contextPath)) {
                HttpUtils.applicationMapping.get(contextPath).shutdownServlets();
                HttpUtils.applicationMapping.remove(contextPath);
            }
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<HTML><BODY>");
            out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                    HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                    HttpUtils.getErrorLogButton());
            out.print(getApplicationForm(contextPath, webXmlPath, classPath));
            out.print(getApplications());
            out.println("</BODY></HTML>");
        } else {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<HTML><BODY>");
            out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                    HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                    HttpUtils.getErrorLogButton());
            out.print(getApplicationForm("e.g. /app", "e.g. conf/web.xml", "e.g. /home/cis455/workspace/HW1/target/WEB-INF/lib/app2.jar"));
            out.print(getApplications());
            out.println("</BODY></HTML>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String contextPath = request.getParameter("context_path");
        String classPath = request.getParameter("classpath");
        String webXmlPath = request.getParameter("webxml_path");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpServletApplication app;


        if (contextPath.length() == 0) {
            out.println("<HTML><BODY>");
            out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                    HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                    HttpUtils.getErrorLogButton());
            out.println("<p style=\"color:red\">You must specify an application name (context path)</p>");
            out.print(getApplicationForm(contextPath, webXmlPath, classPath));
            out.print(getApplications());
            out.println("</BODY></HTML>");
            return;
        }

        // add classpath
        try {
            addClasspath(classPath);
        } catch (Exception e) {
            out.println("<HTML><BODY>");
            out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                    HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                    HttpUtils.getErrorLogButton());
            out.println("<p style=\"color:red\">Cannot add classpath! Please check your classpath</p>");
            out.print(getApplicationForm(contextPath, webXmlPath, classPath));
            out.print(getApplications());
            out.println("</BODY></HTML>");
            return;
        }

        if (!contextPath.startsWith("/")) contextPath = "/" + contextPath;
        try {
            app = new HttpServletApplication(webXmlPath, classPath, contextPath);
        } catch (Exception e) {
            String msg;
            if (e instanceof FileNotFoundException) {
                msg = "Cannot find web.xml. Please check your path!";
            } else if (e instanceof ClassNotFoundException) {
                msg = "Cannot load servlets. Please check your classpath! E.g. edu/upenn/cis455/webserver";
            } else {
                msg = "Loading failed. Please check your web.xml and servlets!";
            }
            out.println("<HTML><BODY>");
            out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                    HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                    HttpUtils.getErrorLogButton());
            out.println("<p style=\"color:red\">" + msg + "</p>");
            out.print(getApplicationForm(contextPath, webXmlPath, classPath));
            out.print(getApplications());
            out.println("</BODY></HTML>");
            return;
        }
        HttpUtils.applicationMapping.put(contextPath, app);
        out.println("<HTML><BODY>");
        out.println(HttpUtils.getSEASLogin() + HttpUtils.getReturnButton() +
                HttpUtils.getShutdownButton() + HttpUtils.getControlButton() + HttpUtils.getFullLogButton() +
                HttpUtils.getErrorLogButton());
        out.print(getApplicationForm("e.g. /app", "e.g. conf/web.xml", "e.g. /home/cis455/workspace/HW1/target/WEB-INF/lib/app2.jar"));
        out.print(getApplications());
        out.println("</BODY></HTML>");
    }

    private String getApplications() {
        String content = "<table>\n" +
                "  <tr>\n" +
                "    <th style=\"border: 1px solid #dddddd;min-width:300px\">Context Path</th>\n" +
                "    <th style=\"border: 1px solid #dddddd;min-width:300px\">Classpath</th> \n" +
                "    <th style=\"border: 1px solid #dddddd;min-width:300px\">Action</th>\n" +
                "  </tr>";
        for (Map.Entry<String, HttpServletApplication> entry : HttpUtils.applicationMapping.entrySet()) {
            content += getApplication(entry);
        }
        content += "</table>";
        return content;
    }

    private String getApplication(Map.Entry<String, HttpServletApplication> entry) {
        String action = "<a href=/manage_applications/delete?" +
                encode("context_path") + "=" + encode(entry.getKey()) + "&" + encode("webxml_path") + "=" +
                encode(entry.getValue().pathWebXml) + "&classpath=" + encode(entry.getValue().classpath) +
                ">Unload/Reload</a>";
        if (entry.getKey().equals("/")) action = "";
        String content =
                "  <tr>\n    <th style=\"border: 1px solid #dddddd;min-width:300px\">" + entry.getKey() + "</th>\n" +
                "    <th style=\"border: 1px solid #dddddd;min-width:300px\">" + entry.getValue().classpath + "</th> \n" +
                "    <th style=\"border: 1px solid #dddddd;min-width:300px\">" + action + "</th>\n" +
                "  </tr>";
        return content;
    }

    private String encode(String url) {
        try {
            return URLEncoder.encode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return url;
        }
    }

    private String getApplicationForm(String contextPath, String webxmlPath, String classpath) {
        String content =
                "<hr><form action=\"/manage_applications/add\" method=\"post\">\n" +
                        "  Context path:<br>\n" +
                        "  <input style=\"color:grey;min-width:500px\" type=\"text\" name=\"context_path\" value=\"" + contextPath + "\">\n" +
                        "  <br>\n" +
                        "  web.xml path:<br>\n" +
                        "  <input style=\"color:grey;min-width:500px\" type=\"text\" name=\"webxml_path\" value=\"" + webxmlPath + "\">\n" +
                        "  <br>\n" +
                        "  Classpath:<br>\n" +
                        "  <input style=\"color:grey;min-width:500px\" type=\"text\" name=\"classpath\" value=\"" + classpath + "\">\n" +
                        "  <br><br>\n" +
                        "  <input type=\"submit\" value=\"Load New Application\">\n" +
                        "</form><hr>";
        return content;
    }

    private void addClasspath(String classpath) throws MalformedURLException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, FileNotFoundException {
        File file = new File(classpath);
        if (!file.exists()) throw new FileNotFoundException("Cannot find jar file");
        URL url = file.toURI().toURL();
        URLClassLoader classLoader = (URLClassLoader)ClassLoader.getSystemClassLoader();
        Method method = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
        method.setAccessible(true);
        method.invoke(classLoader, url);
    }
}
