package edu.upenn.cis455.webserver;
import javax.servlet.ServletContext;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;

/**
 * Created by QingxiaoDong on 2/11/17.
 * https://tomcat.apache.org/tomcat-5.5-doc/servletapi/javax/servlet/ServletConfig.html
 * A servlet configuration object used by a servlet container to pass information
 * to a servlet during initialization.
 */
public class HttpServletConfig implements javax.servlet.ServletConfig {

    private String name;
    private HttpServletContext context;
    private HashMap<String,String> initParams;

    public HttpServletConfig(HttpServletContext context) {
        this.context = context;
    }

    public HttpServletConfig(String name, HttpServletContext context, HttpServletApplication app) {
        this.name = name;
        this.context = context;
        this.initParams = new HashMap<String,String>();
        HashMap<String,String> servletParams = app.h.servletParams.get(name);
        if (servletParams != null) {
            for (String param : servletParams.keySet()) {
                initParams.put(param, servletParams.get(param));
            }
        }
    }

    /**
     * Returns the name of this servlet instance.
     * @return the name of the servlet instance
     */
    public String getServletName() {
        return name;
    }

    /**
     * Returns a reference to the HttpServletContext in which the caller is executing.
     * @return a HttpServletContext object, used by the caller to interact with its servlet container
     */
    public ServletContext getServletContext() {
        return context;
    }

    /**
     * Returns a String containing the value of the named initialization parameter,
     * or null if the parameter does not exist.
     * @param name
     * @return
     */
    public String getInitParameter(String name) {
        return initParams.get(name);
    }

    /**
     * Returns the names of the servlet's initialization parameters as an Enumeration of String
     * objects, or an empty Enumeration if the servlet has no initialization parameters.
     * @return an Enumeration of String objects containing the names of the servlet's
     * initialization parameters
     */
    public Enumeration getInitParameterNames() {
        return Collections.enumeration(initParams.keySet());
    }
}
