package edu.upenn.cis455.webserver;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import java.util.*;

/**
 * Created by QingxiaoDong on 2/11/17.
 * http://docs.oracle.com/javaee/5/api/javax/servlet/http/HttpSession.html
 * Provides a way to identify a user across more than one page request or
 * visit to a Web site and to store information about that user.
 */
public class HttpServletSession implements HttpSession {

    private long creationTime;
    private String id;
    private boolean isValid;
    private boolean isNew;
    private long lastAccessedTime;
    private ServletContext context;
    private int maxInactiveInterval;
    private HashMap<String,Object> attributes;
    private HttpServletApplication application;

    public HttpServletSession(ServletContext context, HttpServletApplication app) {
        application = app;
        creationTime = (new Date()).getTime();
        id = UUID.randomUUID().toString();
        isValid = true;
        isNew = true;
        lastAccessedTime = creationTime;
        maxInactiveInterval = application.h.sessionTimeout;
        attributes = new HashMap<String, Object>();
        this.context = context;
        application.sessions.put(id, this);
    }

    /**
     * Returns the time when this session was created, measured in milliseconds
     * since midnight January 1, 1970 GMT.
     * @return a long specifying when this session was created, expressed in milliseconds since 1/1/1970 GMT
     */
    
    public long getCreationTime() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return creationTime;
    }

    /**
     * Returns a string containing the unique identifier assigned to this session.
     * @return a string specifying the identifier assigned to this session
     */
    
    public String getId() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return id;
    }

    /**
     * Returns the last time the client sent a request associated with this session, as the number
     * of milliseconds since midnight January 1, 1970 GMT, and marked by the time the container
     * received the request.
     * @return a long representing the last time the client sent a request associated with this
     * session, expressed in milliseconds since 1/1/1970 GMT
     */
    
    public long getLastAccessedTime() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return lastAccessedTime;
    }

    /**
     * Returns the ServletContext to which this session belongs.
     * @return The ServletContext object for the web application
     */
    
    public ServletContext getServletContext() {
        return context;
    }

    /**
     * Specifies the time, in seconds, between client requests before the servlet container will
     * invalidate this session. A negative time indicates the session should never timeout.
     * @param interval
     */
    
    public void setMaxInactiveInterval(int interval) {
        maxInactiveInterval = interval;
    }

    /**
     * Returns the maximum time interval, in seconds, that the servlet container will keep this
     * session open between client accesses. After this interval, the servlet container will
     * invalidate the session. The maximum time interval can be set with the setMaxInactiveInterval
     * method. A negative time indicates the session should never timeout.
     * @return an integer specifying the number of seconds this session remains open between client
     * requests
     */
    
    public int getMaxInactiveInterval() {
        return maxInactiveInterval;
    }

    /**
     * Deprecated. Return null.
     * @deprecated
     */
    
    public HttpSessionContext getSessionContext() {
        return null;
    }

    /**
     * Returns the object bound with the specified name in this session, or null if no object is
     * bound under the name.
     * @param name a string specifying the name of the object
     * @return the object with the specified name
     */
    
    public Object getAttribute(String name) {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return attributes.get(name);
    }

    /**
     * Deprecated. Return null.
     * @param name
     * @deprecated
     */
    
    public Object getValue(String name) {
        return null;
    }

    /**
     * Returns an Enumeration of String objects containing the names of all the objects bound to this session.
     * @return an Enumeration of String objects specifying the names of all the objects bound to this session
     */
    
    public Enumeration getAttributeNames() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return Collections.enumeration(attributes.keySet());
    }

    /**
     * Deprecated. Return null.
     * @deprecated
     */
    
    public String[] getValueNames() {
        return null;
    }

    /**
     * Binds an object to this session, using the name specified. If an object of the same name is
     * already bound to the session, the object is replaced.
     * TODO: listener?
     * After this method executes, and if the new object implements HttpSessionBindingListener,
     * the container calls HttpSessionBindingListener.valueBound. The container then notifies any
     * HttpSessionAttributeListeners in the web application.
     * If an object was already bound to this session of this name that implements
     * HttpSessionBindingListener, its HttpSessionBindingListener.valueUnbound method is called.
     * If the value passed in is null, this has the same effect as calling removeAttribute().
     * @param name the name to which the object is bound; cannot be null
     * @param value the object to be bound
     */
    
    public void setAttribute(String name, Object value) {
        if (!isValid) throw new IllegalStateException("invalidated session");
        if (value == null) removeAttribute(name);
        else attributes.put(name, value);
    }

    /**
     * Deprecated. Do nothing.
     * @param name
     * @param value
     * @deprecated
     */
    
    public void putValue(String name, Object value) {

    }

    /**
     * Removes the object bound with the specified name from this session. If the session does not
     * have an object bound with the specified name, this method does nothing.
     * TODO: listener?
     * After this method executes, and if the object implements HttpSessionBindingListener,
     * the container calls HttpSessionBindingListener.valueUnbound. The container then notifies
     * any HttpSessionAttributeListeners in the web application.
     * @param name
     */
    
    public void removeAttribute(String name) {
        if (!isValid) throw new IllegalStateException("invalidated session");
        attributes.remove(name);
    }

    /**
     * Deprecated. Do nothing.
     * @param name
     * @deprecated
     */
    
    public void removeValue(String name) {

    }

    /**
     * Invalidates this session then unbinds any objects bound to it.
     * TODO: unbind
     */
    
    public void invalidate() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        isValid = false;
        application.sessions.remove(id);
    }

    /**
     * Returns true if the client does not yet know about the session or
     * if the client chooses not to join the session. For example, if the
     * server used only cookie-based sessions, and the client had disabled
     * the use of cookies, then a session would be new on each request.
     * @return true if the server has created a session, but the client has not yet joined
     */
    
    public boolean isNew() {
        if (!isValid) throw new IllegalStateException("invalidated session");
        return isNew;
    }

    public boolean isValid() {
        return isValid;
    }

    public void access() {
        lastAccessedTime = (new Date()).getTime();
        isNew = false;
        if (maxInactiveInterval > 0) {
            if (lastAccessedTime - creationTime > maxInactiveInterval * 1000) {
                isValid = false;
            }
        }
    }
}
