package edu.upenn.cis455.webserver;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletInputStream;
import javax.servlet.http.*;
import java.io.*;
import java.net.Socket;
import java.net.URLDecoder;
import java.security.Principal;
import java.util.*;
import javax.servlet.http.HttpSession;

/**
 * Created by QingxiaoDong on 2/13/17.
 */
public class HttpServletRequest implements javax.servlet.http.HttpServletRequest {

    private String port;
    public String method;
    public String version;
    public String body;
    private HashMap<String, Object> attributes;
    private String characterEncoding;
    private Locale locale;
    private HashMap<String, Object> headers;
    private List<Cookie> cookies;
    private HttpServletUri uri;
    private String requestedSessionId;
    private ServletContext servletContext;
    private String remoteHost;
    private String remoteAddr;
    private int remotePort;
    private HttpServletSession session;
    public Map<String, String[]> params;
    private HttpServletApplication application;


    public HttpServletRequest(HttpRequest request, ServletContext context, Socket socket, HttpServletApplication app) {
        method = request.method == null ? request.rawMethod : request.method.text();
        version = request.version == null ? request.rawVersion : request.version.text();
        body = request.body;
        attributes = new HashMap<String, Object>();
        characterEncoding = "ISO-8859-1";
        headers = new HashMap<String, Object>(request.rawHeaders);
        uri = new HttpServletUri(request.pathToFile, app);
        port = request.port;
        servletContext = context;
        remoteAddr = socket.getInetAddress().getHostAddress();
        remoteHost = socket.getInetAddress().getHostName();
        remotePort = socket.getPort();
        application = app;

        // parse cookies
        parseCookies();

        // parse parameters
        try {
            params = new HashMap<String, String[]>();
            parseParameters(uri.queryString);
            parseParameters(request.body);
        } catch (UnsupportedEncodingException e) {}
    }

    private void parseCookies() {
        cookies = new ArrayList<Cookie>();
        if (headers.containsKey(HttpEnum.HEADER_COOKIE.textLowercase())) {
            Object rawCookie = headers.get(HttpEnum.HEADER_COOKIE.textLowercase());
            if (rawCookie instanceof List) {
                for (String c : (List<String>) rawCookie) {
                    cookies.addAll(getCookies(c));
                }
            } else {
                cookies.addAll(getCookies((String) rawCookie));
            }
        }
    }

    private void parseParameters(String queryString) throws UnsupportedEncodingException {
        if (queryString == null) return;
        String[] toks = queryString.split("&");
        for (String tok : toks) {
            String[] p = tok.split("=");
            if (p.length < 1) return;
            String key = URLDecoder.decode(p[0], "UTF-8");
            String value = null;
            if (p.length == 1) {
                value = "";
            } else {
                value = URLDecoder.decode(p[1], "UTF-8");
            }
            if (params.containsKey(key)) {
                String[] values = new String[params.get(key).length + 1];
                System.arraycopy(params.get(key), 0, values, 0, params.get(key).length);
                values[values.length - 1] = value;
                params.put(key, values);
            } else {
                params.put(key, new String[] {value});
            }
        }
    }


    private List<Cookie> getCookies(String value) {
        List<Cookie> cookies = new ArrayList<Cookie>();
        String[] toks = value.split(";");
        for (String tok : toks) {
            String[] cookieTok = tok.split("=");
            if (cookieTok.length > 1) {
                Cookie cookie = new Cookie(cookieTok[0].trim(), cookieTok[1].trim());
                cookies.add(cookie);
                if (cookie.getName().equalsIgnoreCase("sessionid")) {
                    requestedSessionId = cookie.getValue();
                    if (application.sessions.get(requestedSessionId) != null) {
                        session = application.sessions.get(requestedSessionId);
                    }
                    if (session != null) session.access();
                }
            }
        }
        return cookies;
    }

    boolean hasSession() {
        return ((session != null) && session.isValid());
    }

    /**
     * Returns the name of the authentication scheme used to protect the servlet.
     * @return BASIC_AUTH
     */
    
    public String getAuthType() {
        return BASIC_AUTH;
    }


    /**
     * Returns an array containing all of the Cookie objects the client sent with this
     * request. This method returns null if no cookies were sent.
     * @return an array of all the Cookies included with this request, or null if the
     * request has no cookies
     */
    
    public Cookie[] getCookies() {
        return cookies.toArray(new Cookie[cookies.size()]);
    }

    /**
     * Returns the value of the specified request header as a long value that represents a Date object.
     * @param name a String specifying the name of the header
     * @return a long value representing the date specified in the header expressed as the number of
     * milliseconds since January 1, 1970 GMT, or -1 if the named header was not included with the
     * request
     */
    
    public long getDateHeader(String name) {
        String timeString = getHeader(name);
        if (timeString == null) return -1;
        long time = HttpUtils.convertTimeStringToLong(timeString);
        if (time == -1) throw new IllegalArgumentException("Header value can't be converted to a date");
        return time;
    }

    /**
     * Returns the value of the specified request header as a String. If the request did not
     * include a header of the specified name, this method returns null. If there are multiple
     * headers with the same name, this method returns the first head in the request. The header
     * name is case insensitive. You can use this method with any request header.
     * @param name a String specifying the header name
     * @return a String containing the value of the requested header, or null if the request
     * does not have a header of that name
     */
    
    public String getHeader(String name) {
        Object value = headers.get(name.toLowerCase());
        if (value == null) return null;
        if (value instanceof List) {
            return (String) ((List) value).get(0);
        }

        if (HttpUtils.validateTimeFormat((String) value, HttpEnum.VERSION_10)) return (String) value;

        return (String) value;
    }

    /**
     * Returns all the values of the specified request header as an Enumeration of String objects.
     * Some headers, such as Accept-Language can be sent by clients as several headers each with a
     * different value rather than sending the header as a comma separated list.
     * If the request did not include any headers of the specified name, this method returns an
     * empty Enumeration. The header name is case insensitive. You can use this method with any
     * request header.
     * @param name a String specifying the header name
     * @return an Enumeration containing the values of the requested header. If the request does
     * not have any headers of that name return an empty enumeration. If the container does not
     * allow access to header information, return null
     */
    
    public Enumeration getHeaders(String name) {
        List<String> values;
        Object value = headers.get(name.toLowerCase());
        if (value == null) return Collections.emptyEnumeration();
        if (value instanceof List) {
            values = (List) value;
        } else {
            values = new ArrayList<String>();
            values.add((String) value);
        }
        return Collections.enumeration(values);
    }

    /**
     * Returns an enumeration of all the header names this request contains. If the request has no
     * headers, this method returns an empty enumeration.
     * @return
     */
    
    public Enumeration getHeaderNames() {
        return Collections.enumeration(headers.keySet());
    }

    /**
     * Returns the value of the specified request header as an int. If the request does not have a
     * header of the specified name, this method returns -1. If the header cannot be converted to
     * an integer, this method throws a NumberFormatException.
     * The header name is case insensitive.
     * @param name a String specifying the name of a request header
     * @return an integer expressing the value of the request header or -1 if the request
     * doesn't have a header of this name
     */
    
    public int getIntHeader(String name) {
        String s = getHeader(name);
        if (s == null) return -1;
        return Integer.parseInt(s);
    }

    /**
     * Returns the name of the HTTP method with which this request was made, for example,
     * GET, POST, or PUT. Same as the value of the CGI variable REQUEST_METHOD.
     * @return a String specifying the name of the method with which this request was made
     */
    
    public String getMethod() {
        return method;
    }

    /**
     * Returns any extra path information associated with the URL the client sent when it
     * made this request. The extra path information follows the servlet path but precedes
     * the query string and will start with a "/" character.
     * This method returns null if there was no extra path information.
     * @return a String, decoded by the web container, specifying extra path information
     * that comes after the servlet path but before the query string in the request URL;
     * or null if the URL does not have any extra path information
     */
    
    public String getPathInfo() {
        try {
            return URLDecoder.decode(uri.pathInfo, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return uri.pathInfo;
        }
    }

    /**
     * Not implemented. Return null;
     * @return null
     */
    
    public String getPathTranslated() {
        return null;
    }

    /**
     * Returns the portion of the request URI that indicates the context of the request.
     * The context path always comes first in a request URI. The path starts with a "/"
     * character but does not end with a "/" character. For servlets in the default (root)
     * context, this method returns "". The container does not decode this string.
     * @return a String specifying the portion of the request URI that indicates the context
     * of the request
     */
    
    public String getContextPath() {
        return uri.contextPath;
    }

    /**
     * Returns the HTTP GET query string, i.e., the portion after the “?” when a GET form is posted.
     * @return a String containing the query string or null if the URL contains no query string.
     * The value is not decoded by the container.
     */
    
    public String getQueryString() {
        return uri.queryString;
    }

    /**
     * Returns the login of the user making this request, if the user has been authenticated,
     * or null if the user has not been authenticated. Whether the user name is sent with each
     * subsequent request depends on the browser and type of authentication.
     * @return a String specifying the login of the user making this request,
     * or null if the user login is not known
     */
    
    public String getRemoteUser() {
        //@319
        return null;
    }

    /**
     * Not implemented. Return false;
     * @param role
     * @return false
     */
    
    public boolean isUserInRole(String role) {
        return false;
    }

    /**
     * Not implemented. Return null;
     * @return null
     */
    
    public Principal getUserPrincipal() {
        return null;
    }

    /**
     * Returns the session ID specified by the client. This may not be the same as
     * the ID of the current valid session for this request. If the client did not
     * specify a session ID, this method returns null.
     * @return a String specifying the session ID, or null if the request did not
     * specify a session ID
     */
    
    public String getRequestedSessionId() {
        return requestedSessionId;
    }

    /**
     * Returns the part of this request's URL from the protocol name up to the query
     * string in the first line of the HTTP request. The web container does not decode
     * this String. For example:
     * First line of HTTP request	Returned Value
     * POST /some/path.html HTTP/1.1		/some/path.html
     * GET http://foo.bar/a.html HTTP/1.0		/a.html
     * HEAD /xyz?a=b HTTP/1.1		/xyz
     * To reconstruct an URL with a scheme and host, use HttpUtils#getRequestURL.
     * @return a String containing the part of the URL from the protocol name up to the query string
     */
    
    public String getRequestURI() {
        return uri.requestedUri;
    }

    /**
     * Reconstructs the URL the client used to make the request. The returned URL contains a protocol,
     * server name, port number, and server path, but it does not include query string parameters.
     * If this request has been forwarded using RequestDispatcher.forward(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse), the server path in the reconstructed URL must reflect the path
     * used to obtain the RequestDispatcher, and not the server path specified by the client.
     * Because this method returns a StringBuffer, not a string, you can modify the URL easily,
     * for example, to append query parameters.
     * This method is useful for creating redirect messages and for reporting errors.
     * @return a StringBuffer object containing the reconstructed URL
     */
    
    public StringBuffer getRequestURL() {
        StringBuffer sb = new StringBuffer();
        sb.append("http://localhost:").append(port).append(uri.requestedUri);
        return sb;
    }

    /**
     * Returns the part of this request's URL that calls the servlet. This path starts with a "/"
     * character and includes either the servlet name or a path to the servlet, but does not include
     * any extra path information or a query string. Same as the value of the CGI variable SCRIPT_NAME.
     * This method will return an empty string ("") if the servlet used to process this request was
     * matched using the "/*" pattern.
     * @return a String containing the name or path of the servlet being called, as specified in the
     * request URL, decoded, or an empty string if the servlet used to process the request is matched
     * using the "/*" pattern.
     */
    
    public String getServletPath() {
        if (uri.servletPath.equals("/") && application.h.pathMapping.contains("/")) return "/";
        try {
            return URLDecoder.decode(uri.servletPath, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return uri.servletPath;
        }
    }

    /**
     * Returns the current HttpServletSession associated with this request or, if there is no current session
     * and create is true, returns a new session.
     * If create is false and the request has no valid HttpServletSession, this method returns null.
     *
     * To make sure the session is properly maintained, you must call this method before the response is
     * committed. If the container is using cookies to maintain session integrity and is asked to create
     * a new session when the response is committed, an IllegalStateException is thrown.
     * @param create true to create a new session for this request if necessary; false to return null
     *                  if there's no current session
     * @return the HttpServletSession associated with this request or null if create is false and the request
     * has no valid session
     */
    
    public HttpSession getSession(boolean create) {
        if (create) {
            if (!hasSession()) {
                session = new HttpServletSession(servletContext, application);
                application.sessions.put(session.getId(), session);
            }
        } else {
            if (!hasSession()) {
                session = null;
            }
        }
        return session;
    }

    /**
     * Returns the current session associated with this request, or if the request does not have a
     * session, creates one.
     * @return the HttpServletSession associated with this request
     */
    
    public HttpSession getSession() {
        return getSession(true);
    }

    /**
     * Checks whether the requested session ID is still valid. If the client did not specify any
     * session ID, this method returns false.
     * @return true if this request has an id for a valid session in the current session context;
     * false otherwise
     */
    
    public boolean isRequestedSessionIdValid() {
        if (session != null && session.getId().equals(requestedSessionId)) return session.isValid();
        return false;
    }

    /**
     * Checks whether the requested session ID came in as a cookie.
     * @return true if the session ID came in as a cookie; otherwise, false
     */
    
    public boolean isRequestedSessionIdFromCookie() {
        return requestedSessionId != null;
    }

    /**
     * Checks whether the requested session ID came in as part of the request URL.
     * @return true if the session ID came in as part of a URL; otherwise, false
     */
    
    public boolean isRequestedSessionIdFromURL() {
        return false;
    }

    /**
     * Deprecated. Return false.
     * @deprecated
     */
    
    public boolean isRequestedSessionIdFromUrl() {
        return false;
    }

    /**
     * Returns the value of the named attribute as an Object, or null if no attribute of the given name exists.
     * @param name a String specifying the name of the attribute
     * @return an Object containing the value of the attribute, or null if the attribute does not exist
     */
    
    public Object getAttribute(String name) {
        return attributes.get(name);
    }

    /**
     * Returns an Enumeration containing the names of the attributes available to this request.
     * This method returns an empty Enumeration if the request has no attributes available to it.
     * @return an Enumeration of strings containing the names of the request's attributes
     */
    
    public Enumeration getAttributeNames() {
        return Collections.enumeration(attributes.keySet());
    }

    /**
     * Returns “ISO-8859-1” by default, and the results of setCharacterEncoding if it was previously called.
     * @return a String containing the name of the character encoding
     */
    
    public String getCharacterEncoding() {
        return characterEncoding;
    }

    /**
     * Overrides the name of the character encoding used in the body of this request.
     * @param env a String containing the name of the character encoding.
     * @throws UnsupportedEncodingException - if this is not a valid encoding
     */
    
    public void setCharacterEncoding(String env) throws UnsupportedEncodingException {
        URLDecoder.decode("random", env); // this throws exception
        characterEncoding = env;
    }

    /**
     * Returns the length, in bytes, of the request body and made available by the input stream,
     * or -1 if the length is not known.
     * @return an integer containing the length of the request body or -1 if the length is not known
     */
    
    public int getContentLength() {
        return getIntHeader(HttpEnum.HEADER_CONTENT_LENGTH.textLowercase());
    }

    /**
     * Returns the MIME type of the body of the request, or null if the type is not known.
     * @return a String containing the name of the MIME type of the request, or null if the type is not known
     */
    
    public String getContentType() {
        return getHeader(HttpEnum.HEADER_CONTENT_TYPE.textLowercase());
    }

    /**
     * Not implemented. Return null.
     * @return null
     * @throws IOException
     */
    
    public ServletInputStream getInputStream() throws IOException {
        return null;
    }

    /**
     * Returns the value of a request parameter as a String, or null if the parameter
     * does not exist. Request parameters are extra information sent with the request.
     * For HTTP servlets, parameters are contained in the query string or posted form data.
     * You should only use this method when you are sure the parameter has only one value.
     * If the parameter might have more than one value, use getParameterValues(java.lang.String).
     * If you use this method with a multivalued parameter, the value returned is equal
     * to the first value in the array returned by getParameterValues.
     * If the parameter data was sent in the request body, such as occurs with an HTTP POST
     * request, then reading the body directly via getInputStream() or getReader() can
     * interfere with the execution of this method.
     * @param name a String specifying the name of the parameter
     * @return a String representing the single value of the parameter
     */
    
    public String getParameter(String name) {
        if (params.containsKey(name)) {
            return params.get(name)[0];
        } else {
            return null;
        }
    }

    /**
     * Returns an Enumeration of String objects containing the names of the parameters contained
     * in this request. If the request has no parameters, the method returns an empty Enumeration.
     * @return an Enumeration of String objects, each String containing the name of a request
     * parameter; or an empty Enumeration if the request has no parameters
     */
    
    public Enumeration getParameterNames() {
        return Collections.enumeration(params.keySet());
    }

    /**
     * Returns an array of String objects containing all of the values the given request parameter
     * has, or null if the parameter does not exist. If the parameter has a single value, the array
     * has a length of 1.
     * @param name a String containing the name of the parameter whose value is requested
     * @return an array of String objects containing the parameter's values
     */
    
    public String[] getParameterValues(String name) {
        if (params.containsKey(name)) {
            return params.get(name);
        } else {
            return null;
        }
    }

    /**
     * Returns a java.util.Map of the parameters of this request. Request parameters are extra
     * information sent with the request. For HTTP servlets, parameters are contained in the query
     * string or posted form data.
     * @return an immutable java.util.Map containing parameter names as keys and parameter values
     * as map values. The keys in the parameter map are of type String. The values in the parameter
     * map are of type String array.
     */
    
    public Map getParameterMap() {
        return Collections.unmodifiableMap(params);
    }

    /**
     * Returns the name and version of the protocol the request uses in the form protocol/majorVersion.minorVersion,
     * for example, HTTP/1.1.
     * @return
     */
    
    public String getProtocol() {
        return version;
    }

    /**
     * Returns the name of the scheme used to make this request - http.
     * @return a String containing the name of the scheme used to make this reques
     */
    
    public String getScheme() {
        return "http";
    }

    /**
     * Returns the host name of the server to which the request was sent. It is the value of the part
     * before ":" in the Host header value, if any, or the resolved server name, or the server IP address.
     * @return a String containing the name of the server
     */
    
    public String getServerName() {
        String h = getHeader(HttpEnum.HEADER_HOST.textLowercase());
        if (h != null) {
            int i = h.indexOf(":");
            if (i > 0) {
                h = h.substring(0, i);
            }
            return h;
        }
        return "localhost";
    }

    /**
     * Returns the port number to which the request was sent. It is the value of the part after ":"
     * in the Host header value, if any, or the server port where the client connection was accepted on.
     * @return an integer specifying the port number
     */
    
    public int getServerPort() {
        String h = getHeader(HttpEnum.HEADER_HOST.textLowercase());
        if (h != null) {
            int i = h.indexOf(":");
            if (i > 0) {
                h = h.substring(i + 1);
                return Integer.parseInt(h);
            }
        }
        return Integer.parseInt(port);
    }

    /**
     * Retrieves the body of the request as character data using a BufferedReader. The reader
     * translates the character data according to the character encoding used on the body.
     * Either this method or getInputStream() may be called to read the body, not both.
     * @return a BufferedReader containing the body of the request
     * @throws UnsupportedEncodingException - if the character set encoding used is not supported
     * and the text cannot be decoded
     * @throws java.lang.IllegalStateException - if getInputStream() method has been called on this request
     * @throws java.io.IOException - if an input or output exception occurred
     */
    
    public BufferedReader getReader() throws IOException {
        if (body == null) body = "";
        InputStream in = new ByteArrayInputStream(body.getBytes(characterEncoding));
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        return reader;
    }

    /**
     * Returns the Internet Protocol (IP) address of the client or last proxy that sent the request.
     * @return a String containing the IP address of the client that sent the request
     */
    
    public String getRemoteAddr() {
        return remoteAddr;
    }

    /**
     * Returns the fully qualified name of the client or the last proxy that sent the request.
     * If the engine cannot or chooses not to resolve the hostname (to improve performance),
     * this method returns the dotted-string form of the IP address.
     * @return a String containing the fully qualified name of the client
     */
    
    public String getRemoteHost() {
        return remoteHost;
    }

    /**
     * Stores an attribute in this request. Attributes are reset between requests. This method is
     * most often used in conjunction with RequestDispatcher.
     * If the object passed in is null, the effect is the same as calling removeAttribute(java.lang.String).
     * It is warned that when the request is dispatched from the servlet resides in a different
     * web application by RequestDispatcher, the object set by this method may not be correctly retrieved
     * in the caller servlet.
     * @param name a String specifying the name of the attribute
     * @param value the Object to be stored
     */
    
    public void setAttribute(String name, Object value) {
        if (value == null) removeAttribute(name);
        else attributes.put(name, value);
    }

    /**
     * Removes an attribute from this request. This method is not generally needed as attributes
     * only persist as long as the request is being handled.
     * @param name a String specifying the name of the attribute to remove
     */
    
    public void removeAttribute(String name) {
        attributes.remove(name);
    }

    /**
     * Returns null by default, or the results of setLocale if it was previously called.
     * @return the preferred Locale for the client
     */
    
    public Locale getLocale() {
        return locale;
    }

    /**
     * Not implemented. Return null.
     * @return null
     */
    
    public Enumeration getLocales() {
        return null;
    }

    /**
     * Returns a boolean indicating whether this request was made using a secure channel, such as HTTPS.
     * @return a boolean indicating if the request was made using a secure channel
     */
    
    public boolean isSecure() {
        return false;
    }

    /**
     * Not implemented. Return null;
     * @param path
     * @return null
     */
    
    public RequestDispatcher getRequestDispatcher(String path) {
        return null;
    }

    /**
     * Deprecated. Return null.
     * @param path
     * @deprecated
     */
    
    public String getRealPath(String path) {
        return null;
    }

    /**
     * Returns the Internet Protocol (IP) source port of the client or last proxy that sent the request.
     * @return an integer specifying the port number
     */
    
    public int getRemotePort() {
        return remotePort;
    }

    /**
     * Returns the host name of the Internet Protocol (IP) interface on which the request was received.
     * @return a String containing the host name of the IP on which the request was received.
     */
    
    public String getLocalName() {
        return "localhost";
    }

    /**
     * Returns the Internet Protocol (IP) address of the interface on which the request was received.
     * @return a String containing the IP address on which the request was received.
     */
    
    public String getLocalAddr() {
        return "127.0.0.1";
    }

    /**
     * Returns the Internet Protocol (IP) port number of the interface on which the request was received.
     * @return an integer specifying the port number
     */
    
    public int getLocalPort() {
        return Integer.parseInt(port);
    }


    public HttpServletUri getUri() { return uri; }
}
