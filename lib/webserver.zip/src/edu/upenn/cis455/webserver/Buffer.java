package edu.upenn.cis455.webserver;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Created by QingxiaoDong on 2/15/17.
 */
public class Buffer extends ByteArrayOutputStream {

    private OutputStream out;
    private Logger logger = new Logger(this.getClass().getSimpleName());
    public boolean written;
    private boolean bufferSet;
    private HttpServletResponse response;

    public Buffer(OutputStream os, int size, HttpServletResponse response) {
        super(size);
        out = os;
        written = false;
        this.response = response;
        if (size == 0) bufferSet = false;
        else if (size > 0) bufferSet = true;
    }

    @Override
    /**
     * Writes the specified byte to this byte array output stream.
     *
     * @param   b   the byte to be written.
     */
    public synchronized void write(int b) {
        written = true;
        if (!bufferSet) {
            super.write(b);
            return;
        }
        try {
            if (count + 1 > buf.length) {
                if (!response.isCommitted()) {
                    response.commit(null);
                }
                writeTo(out);
                reset();
            }
            buf[count] = (byte) b;
            count += 1;
        } catch (IOException e) {
            logger.error(e, "Error writing to output stream");
            return;
        }
    }

    /**
     * Writes <code>len</code> bytes from the specified byte array
     * starting at offset <code>off</code> to this byte array output stream.
     *
     * @param   b     the data.
     * @param   off   the start offset in the data.
     * @param   len   the number of bytes to write.
     */
    public synchronized void write(byte b[], int off, int len) {
        written = true;
        if (!bufferSet) {
            super.write(b, off, len);
            return;
        }
        if ((off < 0) || (off > b.length) || (len < 0) ||
                ((off + len) - b.length > 0)) {
            throw new IndexOutOfBoundsException();
        }

        if (count + len > buf.length) {
            int cap = buf.length - count;
            System.arraycopy(b, off, buf, count, cap);
            count = cap;
            try {
                if (!response.isCommitted()) {
                    response.commit(null);
                }
                writeTo(out);
                reset();
                write(b, off + cap, len - cap);
            } catch (IOException e) {
                logger.error(e, "Error writing to output stream");
                return;
            }
        } else {
            System.arraycopy(b, off, buf, count, len);
            count += len;
        }
    }
}
