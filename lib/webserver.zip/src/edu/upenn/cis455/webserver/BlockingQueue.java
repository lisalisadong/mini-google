package edu.upenn.cis455.webserver;

import java.util.LinkedList;

/**
 * Implementation of blocking queue.
 */
public class BlockingQueue<E> {

    private int sizeLimit;
    private LinkedList<E> list;

    public BlockingQueue() {
        list = new LinkedList<E>();
        sizeLimit = 100000; // default
    }

    public BlockingQueue(int limit) {
        list = new LinkedList<E>();
        sizeLimit = limit;
    }

    public synchronized void enqueue(E e) throws InterruptedException {
        while (list.size() == sizeLimit) {
            wait(); // blocked
        }

        list.add(e);
        notify(); // wake up blocked worker
    }

    public synchronized E dequeue() throws InterruptedException {
        while (list.isEmpty()) {
            wait(); // blocked
        }

        E e = list.poll();
        notify(); // wake up dispatcher
        return e;
    }

    public int size() {
        return sizeLimit;
    }
}
