package edu.upenn.cis455.webserver;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Set;

/**
 * Created by QingxiaoDong on 2/11/17.
 * https://tomcat.apache.org/tomcat-5.5-doc/servletapi/javax/servlet/ServletContext.html
 */
public class HttpServletContext implements javax.servlet.ServletContext {

    private String contextPath;
    private String contextName;
    private HashMap<String,Object> attributes;
    private HashMap<String,String> initParams;

    public HttpServletContext(){}

    public HttpServletContext(String contextPath, HttpServletApplication app) {
        this.contextPath = contextPath;
        contextName = app.h.applicationName;
        attributes = new HashMap<String,Object>();
        initParams = new HashMap<String,String>();
        for (String param : app.h.contextParams.keySet()) {
            initParams.put(param, app.h.contextParams.get(param));
        }
    }

    /**
     * Returns a HttpServletContext object that corresponds to a specified URL on the server.
     * @param uripath
     * @return
     */
    
    public ServletContext getContext(String uripath) {
        HttpServletApplication app = HttpUtils.dispatchApplication(uripath);
        Servlet servlet = app.dispatchServlet(uripath);
        return servlet.getServletConfig().getServletContext();
    }

    /**
     * Returns the major version of the Java Servlet API that this servlet container supports.
     * All implementations that comply with Version 2.4 must have this method return the integer 2.
     * @return 2
     */
    
    public int getMajorVersion() {
        return 2;
    }

    /**
     * Returns the minor version of the Servlet API that this servlet container supports.
     * All implementations that comply with Version 2.4 must have this method return the integer 4.
     * @return 4
     */
    
    public int getMinorVersion() {
        return 4;
    }

    /**
     * Not implemented. Return null.
     * @param file
     * @return null
     */
    
    public String getMimeType(String file) {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param path
     * @return null
     */
    
    public Set getResourcePaths(String path) {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param path
     * @return null
     */
    
    public URL getResource(String path) throws MalformedURLException {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param path
     * @return null
     */
    
    public InputStream getResourceAsStream(String path) {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param path
     * @return
     */
    
    public RequestDispatcher getRequestDispatcher(String path) {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param path
     * @return
     */
    
    public RequestDispatcher getNamedDispatcher(String path) {
        return null;
    }

    /**
     * Deprecated. Return null.
     * @param name
     * @deprecated
     */
    
    public Servlet getServlet(String name) throws ServletException {
        return null;
    }

    /**
     * Deprecated. Return null.
     * @deprecated
     */
    
    public Enumeration getServlets() {
        return null;
    }

    /**
     * Deprecated. Return null.
     * @deprecated
     */
    
    public Enumeration getServletNames() {
        return null;
    }

    /**
     * Not implemented. Return null.
     * @param msg
     */
    
    public void log(String msg) {

    }

    /**
     * Deprecated. Return null.
     * @param exception
     * @param msg
     * @deprecated
     */
    
    public void log(Exception exception, String msg) {

    }

    /**
     * Not implemented. Return null.
     * @param msg
     * @param throwable
     */
    
    public void log(String msg, Throwable throwable) {

    }

    /**
     * Returns a String containing the real path for a given virtual path. For example,
     * the path "/index.html" returns the absolute file path on the server's filesystem
     * would be served by a request for "http://host/contextPath/index.html", where
     * contextPath is the context path of this HttpServletContext..
     * @param path a String specifying a virtual path
     * @return a String specifying the real path, or null if the translation cannot be performed
     */
    
    public String getRealPath(String path) {
        return "http://localhost:" + HttpServer.port + contextPath + path;
    }

    /**
     * Returns the name and version of the servlet container on which the servlet is running.
     * @return a String containing at least the servlet container name and version number
     */
    
    public String getServerInfo() {
        return "Qingxiao Servlet Web Application/1.0";
    }

    /**
     * Returns a String containing the value of the named context-wide initialization parameter,
     * or null if the parameter does not exist.
     * @param name a String containing the name of the parameter whose value is requested
     * @return a String containing at least the servlet container name and version number
     */
    
    public String getInitParameter(String name) {
        return initParams.get(name);
    }

    /**
     * Returns the names of the context's initialization parameters as an Enumeration of String
     * objects, or an empty Enumeration if the context has no initialization parameters.
     * @return an Enumeration of String objects containing the names of the context's
     * initialization parameters
     */
    
    public Enumeration getInitParameterNames() {
        return Collections.enumeration(initParams.keySet());
    }

    /**
     * Returns the servlet container attribute with the given name, or null if there is no
     * attribute by that name.
     * @param name a String specifying the name of the attribute
     * @return an Object containing the value of the attribute, or null if no attribute exists
     * matching the given name
     */
    
    public Object getAttribute(String name) {
        return attributes.get(name);
    }

    /**
     * Returns an Enumeration containing the attribute names available within this servlet context.
     * @return an Enumeration of attribute names
     */
    
    public Enumeration getAttributeNames() {
        return Collections.enumeration(attributes.keySet());
    }

    /**
     * Binds an object to a given attribute name in this servlet context. If the name specified is
     * already used for an attribute, this method will replace the attribute with the new to the
     * new attribute. TODO: listener??
     * If listeners are configured on the HttpServletContext the container notifies them accordingly.
     * If a null value is passed, the effect is the same as calling removeAttribute().
     * @param name a String specifying the name of the attribute
     * @param object an Object representing the attribute to be bound
     */
    
    public void setAttribute(String name, Object object) {
        if (object == null) removeAttribute(name);
        else attributes.put(name, object);
    }

    /**
     * Removes the attribute with the given name from the servlet context.
     * If listeners are configured on the HttpServletContext the container notifies them accordingly.
     * @param name a String specifying the name of the attribute to be removed
     */
    
    public void removeAttribute(String name) {
        attributes.remove(name);
    }

    /**
     * Returns the name of this web application corresponding to this HttpServletContext as specified
     * in the deployment descriptor for this web application by the display-name element.
     * @return The name of the web application or null if no name has been declared in the deployment descriptor.
     */
    
    public String getServletContextName() {
        return contextName;
    }


}
