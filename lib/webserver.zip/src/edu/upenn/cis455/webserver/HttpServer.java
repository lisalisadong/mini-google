package edu.upenn.cis455.webserver;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import java.net.*;
import java.io.*;
import java.util.HashMap;

/**
 * HTTP Servers that support basic HTTP/1.0 and HTTP/1.1 GET and HEAD
 */
public class HttpServer {

	private final int SOCKET_TIMEOUT = 30000;//30s timeout
	private boolean shutdownRequested;
	private ServerSocket serverSocket;
	private Logger logger = new Logger(this.getClass().getSimpleName());
	private BlockingQueue<Socket> queue;
	static String port;
	private String rootDir;
	private Thread mainThread;
	static Thread[] pool;
	static HashMap<Thread, String> workMapping = new HashMap<Thread, String>();

	public HttpServer(int port, String dir, int poolSize, int queueSize) throws IOException {
		serverSocket = new ServerSocket(port, queueSize * 5);
		queue = new BlockingQueue<Socket>(queueSize);
		rootDir = dir;
		mainThread = Thread.currentThread();
		pool = new Thread[poolSize];
		shutdownRequested = false;
		this.port = String.valueOf(port);
	}

	/**
	 * Start accepting sockets and putting sockets into blocking queue
	 */
	public void startAcceptingRequest() {
		logger.warn("Accepting request on port {} ...", Integer.toString(serverSocket.getLocalPort()));
		while (!shutdownRequested) {
			try {
				Socket s = serverSocket.accept();
				logger.trace("Just connected to {}", s.getRemoteSocketAddress().toString());
				queue.enqueue(s);
			} catch (SocketTimeoutException s) {
				// Socket time out
				logger.warn("Socket timeout is reached");
				break;
			} catch (SocketException e) {
				// Server is closed
				logger.warn("Socket is closed");
				break;
			} catch (IOException e) {
				logger.warn("IOException when accepting request");
				break;
			} catch (InterruptedException e) {
				// interrupted by shutdown request
				logger.warn("Socket stopped accepting request");
				break;
			}
		}
	}

	/**
	 * Start thread pools to handle requests
	 */
	public void startHandlingRequest() {
		for (int i = 0; i < pool.length; i++) {
			pool[i] = new Thread() {
				@Override
				public void run() {
					handleRequest();
				}
			};
			pool[i].start();
		}
	}

	/**
	 * Interrupt all blocked threads, until all threads finishes their work
	 */
	private void joinAllThreads() {
		for (Thread t : pool) {
			if (t != Thread.currentThread()) {
				t.interrupt();
			}
		}
		if (mainThread.getState() != Thread.State.RUNNABLE) {
			mainThread.interrupt();
		}
		logger.warn("All threads are joined");
	}

	/**
	 * Join the last thread who handles /shutdown request
	 */
	private void joinLastThread() {
		for (Thread t : pool) {
			try {
				t.join();
			} catch (InterruptedException e) {
				logger.warn("Interrupted when joining all threads");
			}
		}
	}

	/**
	 * Polls a socket from blocking queue and handles it
	 */
	private void handleRequest() {
		Socket socket = null;
		while (!shutdownRequested) {
			try {
				socket = queue.dequeue();
				socket.setSoTimeout(SOCKET_TIMEOUT);

				// update work mapping
				InputStream in = socket.getInputStream();
				OutputStream out = socket.getOutputStream();
				HttpRequest request = new HttpRequest(in, port);
				HttpResponse response = new HttpResponse(request, out, rootDir, port);
				request.processInitialRequest();
				workMapping.put(Thread.currentThread(), (request.badRequest) ? "bad request" : request.pathToFile);
				request.processFullRequest();

				HttpServlet servlet = null;
				HttpServletApplication application = HttpUtils.dispatchApplication(request.pathToFile);
				// dispatch application
				if (application != null) {
					servlet = application.dispatchServlet(request.pathToFile);
				}
				// manage applications
				if (request.pathToFile != null && request.pathToFile.startsWith("/manage_applications")) {
					servlet = new HttpServletApplicationManager();
					HttpServletContext context = new HttpServletContext();
					HttpServletConfig config = new HttpServletConfig(context);
					servlet.init(config);
				}
				if (servlet == null) {
					// regular request
					response.processContinueResponse();
					response.processFullResponse();
					in.close();
					out.close();
					socket.close();

					// handle shutdown
					if (response.shutdownRequested) {
						logger.warn("Shutdown requested");
						shutdownRequested = true;
						joinAllThreads();
						serverSocket.close();
					}
				} else {
					// servlet request
					HttpServletRequest req = new HttpServletRequest(request, servlet.getServletContext(), socket, application);
					HttpServletResponse resp = new HttpServletResponse(out, servlet.getServletContext(), req);
					try {
						servlet.service(req, resp);
					} catch (Exception e) {
						resp.sendError(500);
						logger.error(e, "Servlet error occurs");
					}
					resp.flushBuffer();
					socket.close();
				}
			} catch (InterruptedException e) {
				logger.debug("Thread is interrupted");
			} catch (SocketTimeoutException e) {
				logger.warn("Socket timeout. Closing idle connection.");
			} catch (IOException e) {
				logger.error(e, "IOException when handle a request");
			} catch (ServletException e) {
				logger.error(e, "Servlet exception occurs when create application manager");
			} finally {
				if (socket != null && !socket.isClosed()) {
					try {
						socket.close();
					} catch (IOException e1) {}
				}
			}
		}
	}

	/**
	 * Shutdown server socket
	 */
	public void destroy() {
		try {
			if (serverSocket != null && !serverSocket.isClosed()) serverSocket.close();
		} catch (IOException e) {
			logger.warn("Exception when closing the server");
		}
	}
  
	public static void main(String args[]) {
		Logger logger = new Logger("Main");
		if (args.length < 3) {
			logger.warn("Author: Qingxiao Dong (qingxiao)");
			logger.warn("Usage: java HttpServer <port number> <root directory> <path to web.xml> [OPTIONAL]<thread pool size>");
			return;
		}

		int port = Integer.parseInt(args[0]);

		// check port range
		if (port < 0 || port > 65535) {
			logger.warn("Port number can only be [0,65535]");
			return;
		}

		String rootDir = args[1];

		// check directory
		File file = new File(rootDir);
		if (!file.exists() || !file.isDirectory()) {
			logger.warn("Directory does not exist, please choose another root directory");
			return;
		}

		// web.xml
		String pathToXML = args[2];
		file = new File(pathToXML);
		if (!file.exists() || file.isDirectory()) {
			logger.warn("web.xml not found, please check your path to web.xml");
			return;
		}

		// pool size
		int poolSize = 10;
		if (args.length > 3) {
			poolSize = Integer.parseInt(args[3]);
		}

		HttpServletApplication application = null;
		try {
			application = new HttpServletApplication(args[2], "", "/");
		} catch (ClassNotFoundException e) {
			logger.error(e, "Cannot find classes in the root src folder! Please check your servlets classes");
			return;
		} catch (Exception e) {
			logger.error(e, "Cannot load servlets based on the web.xml you provide. Please check error_log.txt for details");
			return;
		}

		HttpUtils.applicationMapping.put("/", application);

		// start server
		try {
			logger.warn("starting server with pool size " + poolSize);
			final HttpServer s = new HttpServer(port, rootDir, poolSize, 1000);
			s.startHandlingRequest();
			s.startAcceptingRequest();
			s.joinLastThread();
			for (HttpServletApplication app : HttpUtils.applicationMapping.values()) {
				app.shutdownServlets();
			}
			s.destroy();
		} catch (BindException e) {
			// permission denied
			logger.error(e, "Cannot bind server to port " + port + ", please try a different port (e.g. 8080)");
		} catch (IOException e) {
			logger.error(e, "IOException when starting server");
		}
	}

}
