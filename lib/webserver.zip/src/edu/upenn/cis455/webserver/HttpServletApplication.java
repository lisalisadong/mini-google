package edu.upenn.cis455.webserver;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;

/**
 * Created by QingxiaoDong on 2/19/17.
 */
public class HttpServletApplication {
    private Logger logger = new Logger(getClass().getSimpleName());
    public String pathWebXml;
    public String contextPath;
    public String classpath;
    public Handler h;
    public HashMap<String,HttpServlet> servlets;
    public HashMap<String, HttpServletSession> sessions = new HashMap<String, HttpServletSession>();

    public HttpServletApplication(String pathWebXml, String classpath, String contextPath)
            throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException,
            InstantiationException, ServletException, IllegalAccessException {

        this.pathWebXml = pathWebXml;
        this.classpath = classpath;
        this.contextPath = contextPath;
        parseWebdotxml(pathWebXml);
        createServlets();
    }

    /**
     * Get the servlet url which maps this request url
     */
    public String getServletUrl(String url) {
        PriorityQueue<String> matched = new PriorityQueue<String>(10, new Comparator<String>() {
            public int compare(String o1, String o2) {
                return o2.length() - o1.length();
            }
        });
        if (h.servletsMapping.containsKey(url)) return url;
        for (String p : h.pathMapping) {
            if (url.startsWith(p)) {
                matched.add(p);
            } else if (p.length() > 1 && p.endsWith("/")) {
                if (url.equalsIgnoreCase(p.substring(0, p.length() - 1))) matched.add(p);
            }
        }
        if (matched.isEmpty()) return "";
        return matched.peek();
    }

    /**
     * Dispatch servlet for this request url. Return null if no mapping found
     */
    public HttpServlet dispatchServlet(String url) {
        if (url == null) return null;
        if (!contextPath.equalsIgnoreCase("/")) {
            url = url.substring(contextPath.length());
        }
        if (url.indexOf("?") != -1) {
            url = url.substring(0, url.indexOf("?"));
        }
        PriorityQueue<String> matched = new PriorityQueue<String>(10, new Comparator<String>() {
            public int compare(String o1, String o2) {
                return o2.length() - o1.length();
            }
        });
        if (h.servletsMapping.containsKey(url)) {
            return servlets.get(h.servletsMapping.get(url));
        }
        for (String p : h.pathMapping) {
            if (url.startsWith(p)) {
                matched.add(p);
            } else if (p.length() > 1 && p.endsWith("/")) {
                if (url.equalsIgnoreCase(p.substring(0, p.length() - 1))) matched.add(p);
            }
        }
        if (matched.isEmpty()) return null;
        return servlets.get(h.servletsMapping.get(matched.peek()));
    }

    /**
     * Parse web.xml and create handler
     */
    private void parseWebdotxml(String webdotxml) throws IOException, ParserConfigurationException, SAXException {
        h = new Handler();
        File file = new File(webdotxml);
        if (file.exists() == false) {
            FileNotFoundException e = new FileNotFoundException("web.xml not found");
            logger.error(e, "cannot find {}", file.getPath());
            throw e;
        }
        SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
        parser.parse(file, h);
    }

    /**
     * Shutdown servlets
     */
    public void shutdownServlets() {
        for (HttpServlet s : servlets.values()) {
            s.destroy();
        }
    }

    /**
     * Create servlets
     */
    private void createServlets() throws ClassNotFoundException, ServletException, IllegalAccessException, InstantiationException {
        HttpServletContext context = new HttpServletContext(contextPath, this);
        servlets = new HashMap<String,HttpServlet>();
        for (String servletName : h.servlets.keySet()) {
            String className = h.servlets.get(servletName);
            Class servletClass = Class.forName(className);
            HttpServlet servlet = (HttpServlet) servletClass.newInstance();
            HttpServletConfig config = new HttpServletConfig(servletName, context, this);
            servlet.init(config);
            servlets.put(servletName, servlet);
        }
    }

    public static class Handler extends DefaultHandler {
        private int state = 0;
        private String servletName;
        private String paramName;
        int sessionTimeout = -1;
        String applicationName;
        HashMap<String, String> servlets = new HashMap<String, String>();
        HashMap<String, String> servletsMapping = new HashMap<String, String>();
        HashSet<String> pathMapping = new HashSet<String>();
        HashMap<String, String> contextParams = new HashMap<String, String>();
        HashMap<String, HashMap<String, String>> servletParams = new HashMap<String, HashMap<String, String>>();

        public void startElement(String uri, String localName, String qName, Attributes attributes) {
            if (qName.compareTo("servlet-name") == 0) {
                state = 1;
            } else if (qName.compareTo("servlet-class") == 0) {
                state = 2;
            } else if (qName.compareTo("context-param") == 0) {
                state = 3;
            } else if (qName.compareTo("init-param") == 0) {
                state = 4;
            } else if (qName.compareTo("url-pattern") == 0) {
                state = 5;
            } else if (qName.compareTo("display-name") == 0) {
                state = 6;
            } else if (qName.compareTo("session-timeout") == 0) {
                state = 7;
            } else if (qName.compareTo("param-name") == 0) {
                state = (state == 3) ? 10 : 20;
            } else if (qName.compareTo("param-value") == 0) {
                state = (state == 10) ? 11 : 21;
            }
        }

        public void characters(char[] ch, int start, int length) {
            String value = new String(ch, start, length);
            if (state == 1) {
                servletName = value;
                state = 0;
            } else if (state == 2) {
                servlets.put(servletName, value);
                state = 0;
            } else if (state == 5) {
                if (value.endsWith("*")) {
                    if (value.length() == 1) {
                        value = "/";
                    } else {
                        value = value.substring(0, value.length() - 1);
                    }
                    pathMapping.add(value);
                }
                servletsMapping.put(value, servletName);
                state = 0;
            } else if (state == 6) {
                applicationName = value;
                state = 0;
            } else if (state == 7) {
                sessionTimeout = Integer.parseInt(value) * 60;
                state = 0;
            } else if (state == 10 || state == 20) {
                paramName = value;
            } else if (state == 11) {
                if (paramName == null) {
                    System.err.println("Context parameter value '" + value + "' without name");
                    System.exit(-1);
                }
                contextParams.put(paramName, value);
                paramName = null;
                state = 0;
            } else if (state == 21) {
                if (paramName == null) {
                    System.err.println("Servlet parameter value '" + value + "' without name");
                    System.exit(-1);
                }
                HashMap<String, String> p = servletParams.get(servletName);
                if (p == null) {
                    p = new HashMap<String, String>();
                    servletParams.put(servletName, p);
                }
                p.put(paramName, value);
                paramName = null;
                state = 0;
            }
        }
    }
}
