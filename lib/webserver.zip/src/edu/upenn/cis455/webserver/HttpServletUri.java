package edu.upenn.cis455.webserver;

/**
 * Created by QingxiaoDong on 2/17/17.
 */
public class HttpServletUri {
    public String originalUrl;
    public String contextPath;
    public String servletPath;
    public String pathInfo;
    public String queryString;
    public String requestedUri;
    public HttpServletUri(String url, HttpServletApplication app) {
        originalUrl = url;
        contextPath = app.contextPath;
        if (url.startsWith(app.contextPath)) {
            url = url.substring(app.contextPath.length());
        }

        // basic
        servletPath = app.getServletUrl(url);
        if (servletPath.length() >= url.length()) pathInfo = "/";
        else pathInfo = url.substring(servletPath.length());
        if (!pathInfo.startsWith("/")) pathInfo = "/" + pathInfo;
        if (pathInfo.indexOf("?") != -1) pathInfo = pathInfo.substring(0, pathInfo.indexOf("?"));

        // query string
        int i = originalUrl.indexOf("?");
        if (i == -1) {
            requestedUri = originalUrl;
        } else {
            requestedUri = originalUrl.substring(0, i);
            queryString = originalUrl.substring(i + 1);
        }
    }
}
