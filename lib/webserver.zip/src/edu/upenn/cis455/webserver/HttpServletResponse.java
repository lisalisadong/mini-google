package edu.upenn.cis455.webserver;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;

/**
 * Created by QingxiaoDong on 2/13/17.
 */
public class HttpServletResponse implements javax.servlet.http.HttpServletResponse{
    private Logger logger = new Logger(this.getClass().getSimpleName());

    private Map<String, Object> headers;
    private String version;
    private String status;
    private boolean committed;
    private String charEncoding;
    private OutputStream out;
    private Buffer buffer;
    private boolean writerCalled;
    private int bufferSize = 0;
    private Locale locale;
    private ServletContext context;
    private final byte SPACE = 0x20;
    private final String CRLF = "\r\n";
    private HttpServletUri requestUri;
    private HttpServletRequest request;

    public HttpServletResponse(OutputStream stream, ServletContext context, HttpServletRequest request) {
        headers = new HashMap<String, Object>();
        committed = false;
        version = HttpEnum.VERSION_11.text();
        charEncoding = "ISO-8859-1";
        writerCalled = false;
        out = stream;
        buffer = new Buffer(out, 0, this);
        requestUri = request.getUri();
        setContentType(HttpEnum.CONTENT_TEXT_HTML.text());
        this.context = context;
        this.request = request;
        setStatus(200);
    }

    /**
     * Adds the specified cookie to the response. This method can be called multiple times to
     * set more than one cookie.
     * @param cookie the Cookie to return to the client
     */
    
    public void addCookie(Cookie cookie) {
        StringBuilder sb = new StringBuilder();
        sb.append(cookie.getName()).append("=").append(cookie.getValue());

        // expire
        if (cookie.getMaxAge() >= 0) {
            Date now = new Date();
            String expire = HttpUtils.convertTimeLongToString(now.getTime() + cookie.getMaxAge() * 1000);
            sb.append("; Expires=").append(expire);
        }

        // path
        if (cookie.getPath() != null) {
            sb.append("; Path=").append(cookie.getPath());
        }

        addHeader(HttpEnum.HEADER_SET_COOKIE.text(), sb.toString());
    }

    /**
     * Returns a boolean indicating whether the named response header has already been set.
     * @param name - the header name
     * @return true if the named response header has already been set; false otherwise
     */
    
    public boolean containsHeader(String name) {
        return headers.containsKey(name);
    }

    /**
     * Returns original URL. "You don’ need to provide a fall-back like path encoding if
     * the client doesn’t support cookies."
     * @param url - the url to be encoded.
     * @return the unchanged URL.
     */
    
    public String encodeURL(String url) {
        return url;
    }

    /**
     * Returns original URL. "You don’ need to provide a fall-back like path encoding if
     * the client doesn’t support cookies."
     * @param url - the url to be encoded.
     * @return the unchanged URL.
     */
    
    public String encodeRedirectURL(String url) {
        return null;
    }


    /**
     * @param url
     * @deprecated
     */
    
    public String encodeUrl(String url) {
        return null;
    }

    /**
     * @param url
     * @deprecated
     */
    
    public String encodeRedirectUrl(String url) {
        return null;
    }

    /**
     * Sends an error response to the client using the specified status. The server defaults to
     * creating the response to look like an HTML-formatted server error page containing the
     * specified message, setting the content type to "text/html", leaving cookies and other
     * headers unmodified. If an error-page declaration has been made for the web application
     * corresponding to the status code passed in, it will be served back in preference to the
     * suggested msg parameter.
     * If the response has already been committed, this method throws an IllegalStateException.
     * After using this method, the response should be considered to be committed and should
     * not be written to.
     * @param sc - the error status code
     * @param msg - the descriptive message
     * @throws IOException
     */
    
    public void sendError(int sc, String msg) throws IOException {
        if (committed) throw new IllegalStateException("Response has already been committed");
        setStatus(sc);
        headers.clear();
        setContentType(HttpEnum.CONTENT_TEXT_HTML.text());
        setContentLength(getMessageHtml(msg).length());
        commit(getMessageHtml(msg));
    }

    /**
     * Sends an error response to the client using the specified status code and clearing the buffer.
     * If the response has already been committed, this method throws an IllegalStateException. After
     * using this method, the response should be considered to be committed and should not be written to.
     * @param sc - the error status code
     * @throws IOException
     */
    
    public void sendError(int sc) throws IOException {
        if (committed) throw new IllegalStateException("Response has already been committed");
        setStatus(sc);
        headers.clear();
        commit(null);
    }

    /**
     * Sends a temporary redirect response to the client using the specified redirect location URL.
     * This method can accept relative URLs; the servlet container must convert the relative URL to
     * an absolute URL before sending the response to the client. If the location is relative without
     * a leading '/' the container interprets it as relative to the current request URI. If the
     * location is relative with a leading '/' the container interprets it as relative to the servlet
     * container root.
     * If the response has already been committed, this method throws an IllegalStateException. After
     * using this method, the response should be considered to be committed and should not be written to.
     * @param location
     * @throws IOException
     */
    
    public void sendRedirect(String location) throws IOException {
        if (committed) throw new IllegalStateException("Response has already been committed");
        if (!location.startsWith("/")) location = requestUri.requestedUri + "/" + location;
        location = "http://localhost:" + request.getLocalPort() + location;
        setStatus(302);
        setHeader(HttpEnum.HEADER_LOCATION.text(), location);
        commit(null);
    }

    /**
     * Sets a response header with the given name and date-value. The date is specified in terms of
     * milliseconds since the epoch. If the header had already been set, the new value overwrites
     * the previous one. The containsHeader method can be used to test for the presence of a header
     * before setting its value.
     * @param name - the name of the header to set
     * @param date - the assigned date value
     */
    
    public void setDateHeader(String name, long date) {
        setHeader(name, HttpUtils.convertTimeLongToString(date));
    }

    /**
     * Adds a response header with the given name and date-value. The date is specified in terms of
     * milliseconds since the epoch. This method allows response headers to have multiple values.
     * @param name - the name of the header to set
     * @param date - the additional date value
     */
    
    public void addDateHeader(String name, long date) {
        addHeader(name, HttpUtils.convertTimeLongToString(date));
    }

    /**
     * Sets a response header with the given name and value. If the header had already been set,
     * the new value overwrites the previous one. The containsHeader method can be used to test
     * for the presence of a header before setting its value.
     * @param name - the name of the header
     * @param value- the header value If it contains octet string, it should be encoded according
     *             to RFC 2047 (http://www.ietf.org/rfc/rfc2047.txt)
     */
    
    public void setHeader(String name, String value) {
        headers.put(name, value);
    }

    /**
     * Adds a response header with the given name and value. This method allows response headers
     * to have multiple values.
     * @param name - the name of the header
     * @param value - the additional header value If it contains octet string, it should be encoded
     *              according to RFC 2047 (http://www.ietf.org/rfc/rfc2047.txt)
     */
    
    public void addHeader(String name, String value) {
        if (headers.containsKey(name)) {
            if (headers.get(name) instanceof List) {
                ((List) headers.get(name)).add(value);
            } else {
                List<String> list = new ArrayList<String>();
                list.add((String) headers.get(name));
                list.add(value);
                headers.put(name, list);
            }
        } else {

            headers.put(name, value);
        }
    }

    /**
     * Sets a response header with the given name and integer value. If the header had already been set,
     * the new value overwrites the previous one. The containsHeader method can be used to test for the
     * presence of a header before setting its value.
     * @param name - the name of the header
     * @param value - the assigned integer value
     */
    
    public void setIntHeader(String name, int value) {
        setHeader(name, String.valueOf(value));
    }

    /**
     * Adds a response header with the given name and integer value. This method allows response headers to
     * have multiple values.
     * @param name - the name of the header
     * @param value - the assigned integer value
     */
    
    public void addIntHeader(String name, int value) {
        addHeader(name, String.valueOf(value));
    }

    /**
     * Sets the status code for this response. This method is used to set the return status code when there
     * is no error (for example, for the status codes SC_OK or SC_MOVED_TEMPORARILY). If there is an error,
     * and the caller wishes to invoke an error-page defined in the web application, the sendError method
     * should be used instead.
     * The container clears the buffer and sets the Location header, preserving cookies and other headers.
     * @param sc - the status code
     */
    
    public void setStatus(int sc) {
        status = HttpEnum.getStatusByCode(sc).text();
        buffer.reset();
//        setHeader(HttpEnum.HEADER_LOCATION.text(), "http://localhost:" + request.getLocalPort() + requestUri.requestedUri);
    }

    /**
     * Deprecated.
     * @param i
     * @param s
     * @deprecated
     */
    
    public void setStatus(int i, String s) {

    }

    /**
     * Returns ISO-8859-1.
     * @return ISO-8859-1
     */
    
    public String getCharacterEncoding() {
        return charEncoding;
    }

    /**
     * Returns “text/html” by default, and the results of setContentType if it was previously called.
     * @return a String specifying the content type, for example, text/html; charset=UTF-8.
     */
    
    public String getContentType() {
        return (String) headers.get(HttpEnum.HEADER_CONTENT_TYPE.text());
    }

    /**
     * Not implemented. Returns null.
     * @return null
     * @throws IOException
     */
    
    public ServletOutputStream getOutputStream() throws IOException {
        return null;
    }

    /**
     * Returns a PrintWriter object that can send character text to the client. The PrintWriter
     * uses the character encoding returned by getCharacterEncoding(). If the response's character
     * encoding has not been specified as described in getCharacterEncoding (i.e., the method just
     * returns the default value ISO-8859-1), getWriter updates it to ISO-8859-1.
     * Calling flush() on the PrintWriter commits the response.
     * @return a PrintWriter object that can return character data to the client
     * @throws IOException
     */
    
    public PrintWriter getWriter() throws IOException {
        writerCalled = true;
        return new PrintWriter(buffer, true);
    }

    /**
     * Sets the character encoding (MIME charset) of the response being sent to the client.
     *
     * This method can be called repeatedly to change the character encoding. This method has no
     * effect if it is called after getWriter has been called or after the response has been committed.
     * @param charset - a String specifying only the character set defined by IANA Character Sets
     */
    
    public void setCharacterEncoding(String charset) {
        charEncoding = charset;
    }

    /**
     * Sets the length of the content body in the response In HTTP servlets, this method sets
     * the HTTP Content-Length header.
     * @param len - an integer specifying the length of the content being returned to the client;
     *            sets the Content-Length header
     */
    
    public void setContentLength(int len) {
        setIntHeader(HttpEnum.HEADER_CONTENT_LENGTH.text(), len);
    }

    /**
     * Sets the content type of the response being sent to the client, if the response has not
     * been committed yet. The given content type may include a character encoding specification,
     * for example, text/html;charset=UTF-8. The response's character encoding is only set from
     * the given content type if this method is called before getWriter is called.
     * This method may be called repeatedly to change content type and character encoding. This
     * method has no effect if called after the response has been committed. It does not set the
     * response's character encoding if it is called after getWriter has been called or after the
     * response has been committed.
     * @param type - a String specifying the MIME type of the content
     */
    
    public void setContentType(String type) {
        if (committed) return;
        int i = type.indexOf(";");
        if (i != -1) {
            if (!writerCalled) charEncoding = type.substring(i + 9);
            type = type.substring(0, i);
        }
        setHeader(HttpEnum.HEADER_CONTENT_TYPE.text(), type);
    }

    /**
     * Sets the preferred buffer size for the body of the response. The servlet container will
     * use a buffer at least as large as the size requested. The actual buffer size used can be
     * found using getBufferSize.
     * A larger buffer allows more content to be written before anything is actually sent, thus
     * providing the servlet with more time to set appropriate status codes and headers. A smaller
     * buffer decreases server memory load and allows the client to start receiving data more quickly.
     * This method must be called before any response body content is written; if content has been
     * written or the response object has been committed, this method throws an IllegalStateException.
     * @param size - the preferred buffer size
     */
    
    public void setBufferSize(int size) {
        if (buffer.written || committed)  throw new IllegalStateException("Response has already been committed");
        buffer = new Buffer(out, size, this);
        bufferSize = size;
    }

    /**
     * Returns the actual buffer size used for the response. If no buffering is used, this method returns 0.
     * @return the actual buffer size used
     */
    
    public int getBufferSize() {
        return bufferSize;
    }

    /**
     * Forces any content in the buffer to be written to the client. A call to this method automatically
     * commits the response, meaning the status code and headers will be written.
     * @throws IOException
     */
    
    public void flushBuffer() throws IOException {
        if (!committed) commit(null);
        buffer.writeTo(out);
        buffer.reset();
    }

    /**
     * Clears the content of the underlying buffer in the response without clearing headers or status code.
     * If the response has been committed, this method throws an IllegalStateException.
     */
    
    public void resetBuffer() {
        if (committed) throw new IllegalStateException("Response has already been committed");
        buffer.reset();
    }

    /**
     * Returns a boolean indicating if the response has been committed. A committed response has already had
     * its status code and headers written.
     * @return a boolean indicating if the response has been committed
     */
    
    public boolean isCommitted() {
        return committed;
    }

    /**
     * Clears any data that exists in the buffer as well as the status code and headers. If the response has
     * been committed, this method throws an IllegalStateException.
     */
    
    public void reset() {
        if (committed) throw new IllegalStateException("Response has already been committed");
        setStatus(200);
        headers.clear();
        buffer.reset();
    }

    /**
     * Sets the locale of the response, if the response has not been committed yet. It also sets the
     * response's character encoding appropriately for the locale, if the character encoding has not
     * been explicitly set using setContentType(java.lang.String) or setCharacterEncoding(java.lang.String),
     * getWriter hasn't been called yet, and the response hasn't been committed yet. If the deployment
     * descriptor contains a locale-encoding-mapping-list element, and that element provides a mapping
     * for the given locale, that mapping is used. Otherwise, the mapping from locale to character
     * encoding is container dependent.
     * This method may be called repeatedly to change locale and character encoding. The method has no
     * effect if called after the response has been committed. It does not set the response's character
     * encoding if it is called after setContentType(java.lang.String) has been called with a charset
     * specification, after setCharacterEncoding(java.lang.String) has been called, after getWriter has
     * been called, or after the response has been committed.
     *
     * Containers must communicate the locale and the character encoding used for the servlet response's
     * writer to the client if the protocol provides a way for doing so. In the case of HTTP, the locale
     * is communicated via the Content-Language header, the character encoding as part of the Content-Type
     * header for text media types. Note that the character encoding cannot be communicated via HTTP headers
     * if the servlet does not specify a content type; however, it is still used to encode text written via
     * the servlet response's writer.
     * @param locale
     */
    
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * Returns the locale specified for this response using the setLocale(java.util.Locale) method.
     * Calls made to setLocale after the response is committed have no effect. If no locale has been
     * specified, the container's default locale is returned.
     * @return the locale specified for this response
     */
    
    public Locale getLocale() {
        return locale;
    }


    private void addBasicHeaders() {
//        setHeader(HttpEnum.HEADER_SERVER.text(), context.getServletContextName());
//        setDateHeader(HttpEnum.HEADER_DATE.text(), new Date().getTime());
        setHeader(HttpEnum.HEADER_CONNECTION.text(), "close");
    }

    /**
     * Helper functions to help generating the html
     */

    private String getMessageHtml(String message) {
        return  "<html>\n  <body>\n    " + message + "\n  </body>\n</html>" + CRLF;
    }

    public void commit(String message) throws IOException {
        committed = true;
        addBasicHeaders();
        addSessionToCookie();
        commitInitialLine();
        commitHeaders();
        if (message != null) {
            writeResponse(message);
        }
    }

    private void addSessionToCookie() {
        HttpSession session = request.getSession(false);
        if (session != null && ((HttpServletSession) session).isValid()) {
            addCookie(new Cookie("sessionid", session.getId()));
        }
    }

    public void writeResponse(String response) {
        try {
            out.write(response.getBytes());
        } catch (IOException e) {
            logger.error(e, "IOException when writing output stream");
            e.printStackTrace();
        }
    }

    private String getInitialResponse() {
        return version + " " + status + CRLF;
    }

    private void commitInitialLine() {
        writeResponse(getInitialResponse());
    }


    private String getHeaderLine(String header, String value) {
        return header + ": " + value + CRLF;
    }

    private void commitHeaders() {
        for (HashMap.Entry<String, Object> entry : headers.entrySet()) {
            if (entry.getValue() instanceof List) {
                for (String v : (List<String>) entry.getValue()) {
                    writeResponse(getHeaderLine(entry.getKey(), v));
                }
            } else {
                writeResponse(getHeaderLine(entry.getKey(), (String) entry.getValue()));
            }

        }
        writeResponse(CRLF);
    }
}
