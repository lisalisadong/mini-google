package test.edu.upenn.cis455.hw1;
import edu.upenn.cis455.webserver.HttpServletApplication;
import junit.framework.TestCase;
import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.xml.parsers.ParserConfigurationException;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletApplicationTest extends TestCase{
    public void testGetServletUrl() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        assertEquals("/demo/", app.getServletUrl("/demo"));
        assertEquals("/init", app.getServletUrl("/initialization"));
        assertEquals("/demo/", app.getServletUrl("/demo/more"));
        assertEquals("", app.getServletUrl("/demonstration"));
    }

    public void testDispatchServlet() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "/app2", "/app");
        HttpServlet servlet = app.dispatchServlet("/app/demo");
        assertEquals("demo", servlet.getServletName());
        assertEquals(null, app.dispatchServlet("/asdgfagadgasg"));
    }

    public void testWebxmlNotExist() {
        try {
            HttpServletApplication app = new HttpServletApplication("conf/abc/web.xml", "/app2", "/app");
            fail("Exception was not thrown");
        } catch (Exception e) {
            assertTrue(e instanceof FileNotFoundException);
        }
    }

    public void testClassNotFound() {
        try {
            HttpServletApplication app = new HttpServletApplication("conf/app2/web.xml", "/appasfgfg", "/app");
            fail("Exception was not thrown");
        } catch (Exception e) {
            assertTrue(e instanceof ClassNotFoundException);
        }
    }
}
