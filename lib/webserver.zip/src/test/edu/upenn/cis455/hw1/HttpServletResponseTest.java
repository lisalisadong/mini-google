package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.*;
import junit.framework.TestCase;
import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.Socket;
import java.util.Date;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletResponseTest extends TestCase {

    public void testAddCookie() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);
        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpServletResponse response = new HttpServletResponse(out, context, servletRequest);

        Cookie cookie = new Cookie("test", "abc");
        cookie.setMaxAge(60);
        response.addCookie(cookie);
        response.flushBuffer();
        System.out.println(out.toString());
        server.destroy();
    }

    public void testSendError() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);
        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpServletResponse response = new HttpServletResponse(out, context, servletRequest);

        Cookie cookie = new Cookie("test", "abc");
        cookie.setMaxAge(60);
        response.addCookie(cookie);
        response.addHeader("Host", "abc");
        response.sendError(400, "This is bad request");
        System.out.println(out.toString());
        server.destroy();
    }

    public void testSendRedirect() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);
        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpServletResponse response = new HttpServletResponse(out, context, servletRequest);

        Cookie cookie = new Cookie("test", "abc");
        cookie.setMaxAge(60);
        response.addCookie(cookie);
        response.addHeader("Host", "abc");
        response.sendRedirect("black");
        System.out.println(out.toString());
        server.destroy();
    }

    public void testSetDateHeader() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);
        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpServletResponse response = new HttpServletResponse(out, context, servletRequest);
        response.setDateHeader("Date", new Date().getTime());
        response.flushBuffer();
        System.out.println(out.toString());
        server.destroy();
    }
}
