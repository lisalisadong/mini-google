package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.HttpEnum;
import edu.upenn.cis455.webserver.HttpRequest;
import edu.upenn.cis455.webserver.HttpResponse;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpResponseTest extends TestCase{
    public void testProcessContinue() {
        HttpRequest request = new HttpRequest(null, "1234");
        request.method = HttpEnum.METHOD_GET;
        request.version = HttpEnum.VERSION_11;
        request.pathToFile = "/test";
        request.headers.put(HttpEnum.HEADER_HOST, "localhost");
        request.continueExpected = true;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpResponse response = new HttpResponse(request, out, ".", "1234");
        response.processContinueResponse();
        assertEquals("HTTP/1.1 100 Continue\r\n\r\n", out.toString());
    }

    public void testProcessFullResponse() {
        HttpRequest request = new HttpRequest(null, "1234");
        request.method = HttpEnum.METHOD_GET;
        request.version = HttpEnum.VERSION_10;
        request.pathToFile = "/shutdown";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpResponse response = new HttpResponse(request, out, ".", "1234");
        response.processFullResponse();
        assertTrue(out.toString().startsWith("HTTP/1.0 200 OK\r\n"));
    }

    public void testProcessFullResponseNotFound() {
        HttpRequest request = new HttpRequest(null, "1234");
        request.method = HttpEnum.METHOD_GET;
        request.version = HttpEnum.VERSION_10;
        request.pathToFile = "/asdsafdasfsd";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        HttpResponse response = new HttpResponse(request, out, ".", "1234");
        response.processFullResponse();
        assertTrue(out.toString().startsWith("HTTP/1.0 404 Not Found\r\n"));
    }
}
