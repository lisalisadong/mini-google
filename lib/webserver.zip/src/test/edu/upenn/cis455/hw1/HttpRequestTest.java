package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.HttpEnum;
import edu.upenn.cis455.webserver.HttpRequest;
import junit.framework.TestCase;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpRequestTest extends TestCase {
    public void testProcessInitial0() {
        String s = "GET /test HTTP/1.0\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        assertEquals(HttpEnum.METHOD_GET, request.method);
        assertEquals(HttpEnum.VERSION_10, request.version);
        assertEquals("/test", request.pathToFile);
        assertEquals(false, request.badRequest);
        assertEquals(false, request.notSupported);
        assertEquals(false, request.notImplemented);
    }

    public void testProcessInitial1() {
        String s = "GET /test HTTP/1.1\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        assertEquals(HttpEnum.VERSION_11, request.version);
    }

    public void testProcessInitialBadRequest() {
        String s = "GET HTTP/1.0\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        assertEquals(null, request.method);
        assertEquals(null, request.version);
        assertEquals(null, request.pathToFile);
        assertEquals(true, request.badRequest);
    }

    public void testProcessInitialNotImplemented() {
        String s = "DELETE /test HTTP/1.0\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        assertEquals(false, request.badRequest);
        assertEquals(true, request.notImplemented);
    }

    public void testProcessInitialNotSupported() {
        String s = "GET /test HTTP/1.2\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        assertEquals(false, request.badRequest);
        assertEquals(true, request.notSupported);
    }

    public void testProcessFullRequest() {
        String s = "GET /test HTTP/1.0\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        assertEquals(false, request.badRequest);
    }

    public void testProcessFullRequestBad() {
        String s = "GET /test HTTP/1.1\r\n\r\n";
        InputStream in = new ByteArrayInputStream(s.getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        assertEquals(true, request.badRequest);
    }
}
