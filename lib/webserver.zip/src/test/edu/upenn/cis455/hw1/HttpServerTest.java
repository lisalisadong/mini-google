package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.BlockingQueue;
import edu.upenn.cis455.webserver.HttpServer;
import junit.framework.TestCase;

import java.io.IOException;
import java.lang.reflect.Field;

public class HttpServerTest extends TestCase {
    public void testHttpServer() throws IOException, NoSuchFieldException, IllegalAccessException {
	    HttpServer server = new HttpServer(1111, ".", 10, 20);

        // port
        Class<?> serverClass = server.getClass();
        Field f = serverClass.getDeclaredField("port");
        f.setAccessible(true);
        assertEquals("1111",(String) f.get(server));

        // thread pool
        f = serverClass.getDeclaredField("pool");
        f.setAccessible(true);
        assertEquals(10,((Thread[]) f.get(server)).length);

        // blocking queue
        f = serverClass.getDeclaredField("queue");
        f.setAccessible(true);
        assertEquals(20,((BlockingQueue) f.get(server)).size());

        server.destroy();
    }
}
