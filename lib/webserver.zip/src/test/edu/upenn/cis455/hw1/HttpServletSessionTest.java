package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.HttpServletApplication;
import edu.upenn.cis455.webserver.HttpServletContext;
import edu.upenn.cis455.webserver.HttpServletSession;
import junit.framework.TestCase;
import org.xml.sax.SAXException;

import javax.servlet.ServletException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletSessionTest extends TestCase {
    public void testSession() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServletSession session = new HttpServletSession(context, app);
        assertEquals(1800, session.getMaxInactiveInterval());
        assertEquals(session.getCreationTime(), session.getLastAccessedTime());
        assertTrue(session.isNew());
        session.access();
        assertFalse(session.isNew());
        assertTrue(session.getLastAccessedTime() - session.getCreationTime() > 0);
        session.setAttribute("abc", "123");
        assertEquals("123", session.getAttribute("abc"));
        session.setMaxInactiveInterval(0);
        assertTrue(session.isValid());
        session.invalidate();
        assertFalse(session.isValid());
    }
}
