package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.HttpServletApplication;
import edu.upenn.cis455.webserver.HttpServletConfig;
import edu.upenn.cis455.webserver.HttpServletContext;
import junit.framework.TestCase;
import org.xml.sax.SAXException;
import javax.servlet.ServletException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.Enumeration;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletConfigTest extends TestCase {
    public void testGetServletName() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServletConfig config = new HttpServletConfig("demo", context, app);
        assertEquals("demo", config.getServletName());
    }

    public void testGetServletContext() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServletConfig config = new HttpServletConfig("demo", context, app);
        assertEquals(context, config.getServletContext());
    }

    public void testGetInitParamNames() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServletConfig config = new HttpServletConfig("init", context, app);
        Enumeration enumeration = config.getInitParameterNames();
        assertEquals("TestParam", enumeration.nextElement());
        assertFalse(enumeration.hasMoreElements());
    }

    public void testGetInitParam() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServletConfig config = new HttpServletConfig("init", context, app);
        assertEquals("1776", config.getInitParameter("TestParam"));
        assertEquals(null, config.getInitParameter("adfasgfadg"));
    }
}
