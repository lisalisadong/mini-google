package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.*;
import junit.framework.TestCase;
import org.xml.sax.SAXException;
import javax.servlet.ServletException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.Enumeration;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletRequestTest extends TestCase {
    public void testGetHeader() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        InputStream in = new ByteArrayInputStream("GET /test HTTP/1.1\r\nHost: localhost\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("localhost", servletRequest.getHeader("host"));

        server.destroy();
    }

    public void testGetDateHeader() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        long d = HttpUtils.convertTimeStringToLong("Sun, 19 Feb 2017 20:20:17 GMT");
        InputStream in = new ByteArrayInputStream("GET /test HTTP/1.0\r\nIf-Modified-Since: Sun, 19 Feb 2017 20:20:17 GMT\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals(d, servletRequest.getDateHeader("if-modified-since"));

        server.destroy();
    }

    public void testGetIntHeader() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        InputStream in = new ByteArrayInputStream("GET /test HTTP/1.0\r\nCount: 43\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals(43, servletRequest.getIntHeader("count"));

        server.destroy();
    }

    public void testGetHeaders() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        InputStream in = new ByteArrayInputStream("GET /test HTTP/1.0\r\nAccept-Encoding: gzip\r\nAccept-Encoding:br\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        Enumeration enumeration = servletRequest.getHeaders("Accept-Encoding");
        assertEquals("gzip", enumeration.nextElement());
        assertEquals("br", enumeration.nextElement());
        assertFalse(enumeration.hasMoreElements());

        server.destroy();
    }

    public void testGetHeaderNames() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        InputStream in = new ByteArrayInputStream("GET /test HTTP/1.0\r\nAccept-Encoding: gzip\r\nHost:localhost\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        Enumeration enumeration = servletRequest.getHeaderNames();
        assertTrue(enumeration.nextElement().equals("accept-encoding") || enumeration.nextElement().equals("accept-encoding"));
        assertFalse(enumeration.hasMoreElements());

        server.destroy();
    }

    public void testGetMethod() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        InputStream in = new ByteArrayInputStream("POST /test HTTP/1.0\r\nAccept-Encoding: gzip\r\nHost:localhost\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("POST", servletRequest.getMethod());

        server.destroy();
    }

    public void testGetPathInfo() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/", servletRequest.getPathInfo());

        in = new ByteArrayInputStream("GET /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/abc", servletRequest.getPathInfo());

        in = new ByteArrayInputStream("GET /demo/1%402%233%244%205%2F6*7%3D8?a=c HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/1@2#3$4 5/6*7=8", servletRequest.getPathInfo());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/1%402%233%244%205%2F6*7%3D8?a=c HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/1@2#3$4 5/6*7=8", servletRequest.getPathInfo());

        server.destroy();
    }

    public void testGetContextPath() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("", servletRequest.getContextPath());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/1%402%233%244%205%2F6*7%3D8?a=c HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/app", servletRequest.getContextPath());

        server.destroy();
    }

    public void testGetQueryString() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals(null, servletRequest.getQueryString());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/abc?a=1%402%233%244%205%2F6*7%3D8 HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("a=1%402%233%244%205%2F6*7%3D8", servletRequest.getQueryString());

        server.destroy();
    }

    public void testGetRequestedSessionId() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo HTTP/1.0\r\nCookie: sessionid=b462bf93-2545-4a4f-b2b1-961fe6593d17\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("b462bf93-2545-4a4f-b2b1-961fe6593d17", servletRequest.getRequestedSessionId());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/abc?a=1%402%233%244%205%2F6*7%3D8 HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals(null, servletRequest.getRequestedSessionId());

        server.destroy();
    }

    public void testGetRequestedUri() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/demo/abc", servletRequest.getRequestURI());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/abc?a=1%402%233%244%205%2F6*7%3D8 HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/app/demo/abc", servletRequest.getRequestURI());

        server.destroy();
    }

    public void testGetRequestedUrl() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("http://localhost:1234/demo/abc", servletRequest.getRequestURL().toString());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/abc?a=1%402%233%244%205%2F6*7%3D8 HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("http://localhost:1234/app/demo/abc", servletRequest.getRequestURL().toString());

        server.destroy();
    }

    public void testGetServletPath() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpServer server = new HttpServer(1234, ".", 10, 20);
        Socket socket = new Socket("localhost", 1234);

        InputStream in = new ByteArrayInputStream("POST /demo/abc HTTP/1.0\r\n\r\n".getBytes());
        HttpRequest request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        HttpServletRequest servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/demo/", servletRequest.getServletPath());

        app = new HttpServletApplication("conf/web.xml", "", "/app");
        context = new HttpServletContext("/app", app);
        in = new ByteArrayInputStream("GET /app/demo/abc?a=1%402%233%244%205%2F6*7%3D8 HTTP/1.0\r\n\r\n".getBytes());
        request = new HttpRequest(in, "1234");
        request.processInitialRequest();
        request.processFullRequest();
        servletRequest = new HttpServletRequest(request, context, socket, app);
        assertEquals("/demo/", servletRequest.getServletPath());

        server.destroy();
    }
}
