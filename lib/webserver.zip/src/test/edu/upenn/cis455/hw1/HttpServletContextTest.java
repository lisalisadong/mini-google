package test.edu.upenn.cis455.hw1;

import edu.upenn.cis455.webserver.HttpServer;
import edu.upenn.cis455.webserver.HttpServletApplication;
import edu.upenn.cis455.webserver.HttpServletContext;
import edu.upenn.cis455.webserver.HttpUtils;
import junit.framework.TestCase;
import org.xml.sax.SAXException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Created by QingxiaoDong on 2/20/17.
 */
public class HttpServletContextTest extends TestCase {
    public void testGetContext() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpUtils.applicationMapping.put("/", app);
        ServletContext c = context.getContext("/demo");
        HttpServer server = new HttpServer(1112, ".", 10, 20);
        assertEquals("http://localhost:1112/demo", c.getRealPath("/demo"));
        server.destroy();
    }

    public void testGetRealPath() throws IllegalAccessException, ServletException, SAXException, InstantiationException, ClassNotFoundException, ParserConfigurationException, IOException {
        HttpServletApplication app = new HttpServletApplication("conf/web.xml", "", "");
        HttpServletContext context = new HttpServletContext("", app);
        HttpUtils.applicationMapping.put("/", app);
        ServletContext c = context.getContext("/demo");
        HttpServer server = new HttpServer(1113, ".", 10, 20);
        assertEquals("http://localhost:1113/demo", c.getRealPath("/demo"));

        HttpServletApplication newApp = new HttpServletApplication("conf/web.xml", "app2", "/app");
        HttpUtils.applicationMapping.put("/app", newApp);
        c = context.getContext("/app/demo");
        assertEquals("http://localhost:1113/app/demo", c.getRealPath("/demo"));
        server.destroy();
    }
}
